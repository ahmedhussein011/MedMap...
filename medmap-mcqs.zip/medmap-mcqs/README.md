# MedMap MCQs

A mobile-first question-bank web app built from the MedMap MCQ books: practise by topic, take tests, check answers, search every question and track your progress. Plain **HTML + CSS + vanilla JavaScript**, JSON data, and `localStorage` for progress. No backend, no login, no paid services.

* **5,277 questions** from 7 MedMap books (Years 1–3, Modules 101, 102, 205, 309, 310)
* Hierarchy: **Year → Module → Subject → Subtopic → MCQs** (exactly as specified, nothing renamed)
* Official MedMap logos and book covers are used unaltered (only downscaled for the web)

---

## 1. Run it on your computer

Browsers block `fetch()` of local JSON files when you double-click `index.html` (the page then shows a message explaining this). Start a tiny local server instead:

```bash
cd medmap-mcqs
python3 -m http.server 8000
```

Then open <http://localhost:8000>. Any static server works (`npx serve`, VS Code “Live Server”, …).

## 2. Deploy it (GitHub Pages)

1. Create a GitHub repository and upload the **contents** of this folder (keep `index.html` at the top level).
2. In the repository go to **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and save.
3. After a minute the site is live at `https://<your-user>.github.io/<repo>/`.

The folder already contains an empty `.nojekyll` file, and all links are relative, so it also works in a sub-folder or on Netlify, Cloudflare Pages, Vercel or any static host. Total size is about 11 MB (JSON data is gzip-compressed by the host).

## 3. Features

| Area | What you get |
|---|---|
| Navigation | Home → Year → Module → Subject → Subtopic, breadcrumbs, back buttons, source-book cover on every subject |
| Practice mode | Pick an option, **Submit**, see correct/incorrect, the correct answer, explanation (when one exists), Previous/Next, skip |
| Test mode | Answers hidden until you submit; move freely, change answers, see unanswered questions, confirm-to-submit, final score, correct/incorrect/unanswered review |
| Extras | Shuffle questions, shuffle options (answer mapping is by option ID so it can never break), retry incorrect, review all answers, question list to jump anywhere, progress bar (answered / remaining / correct), restart with confirmation, keyboard shortcuts (A–E or 1–5 to pick, Enter to submit/next, ←/→ to move) |
| Dashboard | Total / attempted / correct / incorrect / accuracy, progress by year → module → subject → subtopic, recently practised topics, resume last session, test history, reset (with confirmation) |
| Search | Keywords across questions, options, subject and topic names; filters for year, module, subject and your own progress (unattempted / answered / incorrect / correct); tap a result to open that question |
| Images | Figures stay at their natural aspect ratio; tap to enlarge |
| Settings | Default shuffles, admin/reviewer view, export / import progress |
| Accessibility | Keyboard operable, visible focus, labelled controls, 44 px touch targets, light theme with high-contrast text, respects “reduce motion” |

**Shuffling and “all of the above”:** options that refer to other options (“all of the above”, “a and b”, “none of these” …) are never shuffled, so a question’s meaning is never changed. 125 questions are affected.

## 4. Progress is stored locally (important)

Progress is saved with `localStorage` **in the current browser on the current device**. It does **not** synchronise between phones, computers or browsers, and clearing browser data deletes it. Use **Settings → Export progress / Import progress** to move it yourself. Cloud sync would need a backend and accounts, which this version intentionally does not include.

Statistics count each question **once** (its latest answer), so re-doing a question never inflates “attempted”. Question-bank accuracy is separate from the score of any individual test.

## 5. Answer provenance (accuracy first)

Every question has an `answerStatus`:

| Status | Meaning | Questions |
|---|---|---:|
| `source-verified` | Answer read from the book’s own key (including key **images**), or taken from an identical keyed question elsewhere in the same book | 4,817 |
| `independently-solved` | The book has **no key** for it; answered with medical knowledge. Never presented as coming from the book | 408 |
| `needs-review` | Cancelled in the book, listed with two answers, unreadable, ambiguous, or the book’s key contradicts itself. Shown but **not scored** | 52 |

* Answer keys in these books are images. Every key page was read visually and matched by chapter/section so restarting question numbers cannot cause a mismatch. As a cross-check, 321 duplicated questions that have a key in two places were compared: 318 agree; the other 3 are errors inside the books themselves (marked `needs-review`).
* Students don’t see these statuses. Turn on **Settings → Admin / reviewer view** to see status, source page, notes and tentative answers on each question.
* **No explanations exist in the books**, so the explanation field is empty (`explanation: null`). The app shows one automatically if you add it, labelled “not from the book” unless `explanationSource` is `"original"`.
* Full lists for reviewers: `docs/manual-review.md` (the 52 under-review questions + notes) and `docs/independently-solved.csv` (the 408 solved answers to check).

## 6. Folder structure

```
medmap-mcqs/
├── index.html · style.css · app.js     app shell, styles, logic (no build step)
├── assets/
│   ├── logo/            official MedMap logos (downscaled copies)
│   ├── book-covers/     page 1 of each book
│   ├── question-images/ figures that belong to questions
│   └── extra-content/   non-MCQ pages kept for the planned “Figure Matching” section
├── data/
│   ├── years.json       generated manifest (hierarchy, counts, subtopics)
│   └── module-101 … module-310/   one JSON file per subject
├── docs/                manual-review.md, independently-solved.csv
├── tools/               build_manifest.py, build_review_list.py, extraction/ (provenance scripts)
└── tests/               core.test.js (Node) and ui/ (Playwright)
```

## 7. Question data format

```json
{
  "id": "M101-ANAT-EX2025-Q045",
  "year": 1, "module": "101", "subject": "Anatomy",
  "subtopic": "Previous Exam 2025 (Batch 198)", "subtopicId": "EX2025", "number": 45,
  "question": "…", "options": [{"id": "A", "text": "…"}, {"id": "B", "text": "…"}],
  "correctOptionId": "B",
  "explanation": null, "explanationSource": null,
  "answerStatus": "source-verified",
  "sourceBook": "ISK - 101 | End of Module (MedMap 2027)", "sourcePage": 9, "sourceSection": "Exam 2025",
  "image": null
}
```

Optional fields: `reviewNote`, `answerNote`, `tentativeOptionId`, `sourceKeyOptionId`, `independentOptionId`. Questions may have 2–5 options. `correctOptionId: null` means “under review”.

## 8. Adding questions or a new book

1. Put the questions in `data/module-XXX/<subject>.json` using the format above (stable IDs; `subtopicId` groups questions into subtopics).
2. If it is a **new** subject or module, add it to `HIERARCHY` (and `BOOKS`) in `tools/build_manifest.py`.
3. Run `python3 tools/build_manifest.py` – it rebuilds `data/years.json` and validates the bank (duplicate IDs, answers not among the options, missing images, wrong placement).
4. Run `python3 tools/build_review_list.py` to refresh the reviewer lists.

The UI needs no changes: subjects load on demand, so thousands more questions only cost bandwidth when opened.

## 9. Tests

```bash
node tests/core.test.js                       # shuffle safety, scoring, statistics, data integrity
pip install playwright && playwright install chromium
python3 tests/ui/ui_practice_test_search.py   # practice, test, review, retry, restart, search, dashboard, reset
python3 tests/ui/ui_images_admin_layout.py    # images, 5-option questions, keyboard, admin view, export/import, layout 320–1280 px
```

## 10. Known limitations and next steps

* **Figure Matching** – 11 “match column A with column B” exercises in the NEU-205 book aren’t MCQs and are not in the bank; their pages are in `assets/extra-content/` for the separate section planned next.
* **Explanations** – none in the books; can be added later (flagged as generated).
* **Second human read of the answer keys** is recommended – they were transcribed from images (automated cross-checks found no mismatches, but a person should confirm).
* Light theme only; a dark theme and optional accounts/cloud sync are future work.
