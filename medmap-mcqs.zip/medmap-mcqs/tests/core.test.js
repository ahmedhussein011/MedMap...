// Run with:  node tests/core.test.js
const assert = require('assert'); const fs = require('fs'); const path = require('path');
const C = require('../app.js');
let n = 0; const t = (name, fn) => { fn(); n++; console.log('  ok -', name); };
const q = (opts, correct) => ({id: 'X1', options: opts.map((x, i) => ({id: 'ABCDE'[i], text: x})), correctOptionId: correct, subject: 'Anatomy', module: '101', subtopicId: 'S'});

t('options that refer to each other are never shuffled', () => {
  assert.strictEqual(C.canShuffleOptions(q(['Liver', 'Spleen', 'All of the above', 'Kidney'])), false);
  assert.strictEqual(C.canShuffleOptions(q(['a and b', 'b only', 'c', 'd'])), false);
  assert.strictEqual(C.canShuffleOptions(q(['None of the above', 'x', 'y', 'z'])), false);
  assert.strictEqual(C.canShuffleOptions(q(['Both', 'Neither', 'x', 'y'])), false);
  assert.strictEqual(C.canShuffleOptions(q(['Liver', 'Spleen', 'Pancreas', 'Kidney'])), true);
});
t('shuffling keeps the correct answer mapped to the same option text', () => {
  const question = q(['Liver', 'Spleen', 'Pancreas', 'Kidney'], 'C');
  for (let i = 0; i < 300; i++) {
    const order = C.optionOrder(question, true); const shown = C.orderedOptions(question, order);
    assert.strictEqual(shown.length, 4); assert.strictEqual(new Set(shown.map(o => o.id)).size, 4);
    assert.strictEqual(shown.find(o => o.id === question.correctOptionId).text, 'Pancreas');
  }
});
t('shuffle actually reorders and does not change texts', () => {
  const question = q(['A1', 'B2', 'C3', 'D4', 'E5'], 'B'); let moved = 0;
  for (let i = 0; i < 100; i++) { const o = C.optionOrder(question, true); if (o.join('') !== 'ABCDE') moved++; }
  assert.ok(moved > 80);
  assert.deepStrictEqual(C.optionOrder(question, false), ['A', 'B', 'C', 'D', 'E']);
});
t('question shuffle is a permutation', () => {
  const a = Array.from({length: 50}, (_, i) => i); const b = C.shuffle(a);
  assert.deepStrictEqual(b.slice().sort((x, y) => x - y), a);
});
t('statistics count each question once (latest answer)', () => {
  const S = C.Store; S.data = {answers: {}, recent: [], settings: {}, sessions: {}, tests: []}; S.save = () => {};
  const a = q(['x', 'y', 'z', 'w'], 'B'), b = Object.assign(q(['x', 'y'], 'A'), {id: 'X2'});
  S.record(a, 'A'); S.record(a, 'B'); S.record(a, 'B'); S.record(b, 'B');
  const st = C.statsFrom(S.data.answers);
  assert.strictEqual(st.attempted, 2); assert.strictEqual(st.correct, 1); assert.strictEqual(st.incorrect, 1);
  assert.strictEqual(st.attempts, 4); assert.strictEqual(st.accuracy, 50);
});
t('questions without a key are never scored or recorded', () => {
  const S = C.Store; S.data = {answers: {}, recent: [], settings: {}, sessions: {}, tests: []};
  const nk = Object.assign(q(['x', 'y'], null), {id: 'X3'}); S.record(nk, 'A');
  assert.deepStrictEqual(S.data.answers, {});
});
t('session tally: practice vs test', () => {
  const qs = ['1', '2', '3', '4'].map(i => Object.assign(q(['a', 'b', 'c', 'd'], 'A'), {id: i})); const byId = {}; qs.forEach(x => byId[x.id] = x);
  const unk = Object.assign(q(['a', 'b'], null), {id: '5'}); byId['5'] = unk;
  const test = {mode: 'test', submitted: true, qids: ['1', '2', '3', '4', '5'], sel: {1: 'A', 2: 'B', 5: 'A'}, done: {}};
  assert.deepStrictEqual(C.sessionTally(test, byId), {correct: 1, wrong: 1, unanswered: 2, total: 4});
  const prac = {mode: 'practice', qids: ['1', '2', '3'], sel: {1: 'A', 2: 'C', 3: 'A'}, done: {1: true, 2: true}};
  assert.deepStrictEqual(C.sessionTally(prac, byId), {correct: 1, wrong: 1, unanswered: 1, total: 3});
});
t('real data: every question has 2-5 options, a valid key or needs-review, and unique ids', () => {
  const root = path.join(__dirname, '..', 'data'); const ids = new Set(); let total = 0, noshuffle = 0;
  fs.readdirSync(root).filter(d => d.startsWith('module-')).forEach(d => fs.readdirSync(path.join(root, d)).forEach(f => {
    JSON.parse(fs.readFileSync(path.join(root, d, f), 'utf8')).questions.forEach(x => {
      total++; assert.ok(!ids.has(x.id)); ids.add(x.id); assert.ok(x.options.length >= 2 && x.options.length <= 5, x.id);
      if (x.correctOptionId) assert.ok(x.options.some(o => o.id === x.correctOptionId), x.id); else assert.strictEqual(x.answerStatus, 'needs-review', x.id);
      const order = C.optionOrder(x, true); const shown = C.orderedOptions(x, order);
      if (x.correctOptionId) assert.strictEqual(shown.find(o => o.id === x.correctOptionId).text, x.options.find(o => o.id === x.correctOptionId).text);
      if (!C.canShuffleOptions(x)) noshuffle++;
    });
  }));
  console.log('     questions:', total, '| kept in original option order (options refer to each other):', noshuffle);
  assert.strictEqual(total, 5277);
});
console.log(n + ' tests passed');
