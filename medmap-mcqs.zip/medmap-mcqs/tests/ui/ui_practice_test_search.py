import os
ROOT_DIR=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from playwright.sync_api import sync_playwright
import sys, json
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from testutil import server
res=[]; errs=[]
def ok(name,cond,extra=''):
    res.append((name,bool(cond))); print(('PASS' if cond else 'FAIL'),'-',name,extra)
with server() as BASE, sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True); pg=ctx.new_page()
    pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None); pg.on('pageerror',lambda e: errs.append(str(e)))
    # ---------- Practice: ISK anatomy Exam 2022 (has 2 cancelled = needs-review) ----------
    pg.goto(BASE+'#/topic/101-anatomy/EX2022'); pg.wait_for_selector('form[data-form=start]')
    ok('topic page shows 76 questions',' 76 questions' in pg.inner_text('main'))
    pg.click('button:has-text("Start")'); pg.wait_for_selector('.qcard')
    # answer first 3 correctly by reading data
    data=json.load(open(ROOT_DIR+'/data/module-101/anatomy.json'))['questions']
    qs=[q for q in data if q['subtopicId']=='EX2022']
    def correct_text(q): return next(o['text'] for o in q['options'] if o['id']==q['correctOptionId'])
    for i in range(3):
        q=qs[i]; pg.click(f'.opt:has-text("{correct_text(q)[:25]}") >> nth=0'); pg.click('[data-act=submit]')
        ok(f'practice Q{i+1} marked correct',pg.locator('.feedback.ok').count()==1)
        pg.click('[data-act=next]')
    ok('progress shows 3 answered','Answered 3' in pg.inner_text('.progress-line').replace('\n',' ') or 'Answered\n3' in pg.inner_text('.progress-line'))
    # wrong answer
    q=qs[3]; wrong=next(o for o in q['options'] if o['id']!=q['correctOptionId'])
    pg.click(f'.opt:has-text("{wrong["text"][:25]}") >> nth=0'); pg.click('[data-act=submit]')
    ok('wrong answer marked incorrect',pg.locator('.feedback.bad').count()==1 and pg.locator('.opt.wrong').count()==1 and pg.locator('.opt.correct').count()==1)
    ok('options locked after submit',pg.locator('.opt[disabled]').count()==len(q['options']))
    # reload -> session restored
    pg.reload(); pg.wait_for_selector('.qcard'); ok('session restored after reload (still on question 4, answered)',pg.locator('.feedback.bad').count()==1)
    # question list navigation
    pg.click('[data-act=nav]'); ok('question grid shows 76 buttons',pg.locator('.navgrid button').count()==76)
    ok('grid marks 3 ok + 1 bad',pg.locator('.navgrid button.ok').count()==3 and pg.locator('.navgrid button.bad').count()==1)
    pg.click('.navgrid button >> nth=33'); ok('question list jumps to Q34', 'Question 34' in pg.inner_text('.qnum'))
    # review + retry
    pg.click('[data-act=review]'); pg.wait_for_selector('.score'); ok('review summary 3/4 correct (under-review excluded)','3 / 4' in pg.inner_text('.score'),pg.inner_text('.score').replace('\n',' ')[:60])
    pg.click('[data-act=retryR]'); pg.wait_for_selector('.qcard'); ok('retry incorrect starts a 1-question practice','of 1' in pg.inner_text('.progress-line') or 'of\n1' in pg.inner_text('.progress-line'))
    # dashboard stats
    pg.goto(BASE+'#/dashboard'); pg.wait_for_selector('.stats')
    t=pg.inner_text('.stats').replace('\n',' '); print('   stats:',t)
    ok('dashboard: 4 attempted, 3 correct, 1 incorrect, 75% accuracy','4 Attempted' in t and '3 Correct' in t and '1 Incorrect' in t and '75%' in t)
    # restart with confirmation
    pg.goto(BASE+'#/session/'+'practice%7Csub%3A101-anatomy%3AEX2022'); pg.wait_for_selector('.qcard')
    pg.click('[data-act=restart]'); ok('restart asks for confirmation',pg.locator('.dialog').count()==1)
    pg.click('[data-dlg=no]'); ok('cancel keeps the session','Answered' in pg.inner_text('.progress-line') and pg.locator('.dialog').count()==0)
    pg.click('[data-act=restart]'); pg.click('[data-dlg=yes]'); pg.wait_for_timeout(300)
    ok('confirmed restart clears session to Q1',"Question 1" in pg.inner_text('.qnum'))
    pg.goto(BASE+'#/dashboard'); pg.wait_for_selector('.stats'); ok('restart does not change overall stats','4 Attempted' in pg.inner_text('.stats').replace('\n',' '))
    # ---------- Test mode ----------
    pg.goto(BASE+'#/topic/102-biochemistry/CARB'); pg.wait_for_selector('form[data-form=start]')
    pg.check('input[value=test]'); ok('test-length field appears',pg.locator('.test-only').is_visible()); pg.select_option('select[name=count]','10')
    pg.click('button:has-text("Start")'); pg.wait_for_selector('.qcard')
    ok('test shows Test mode badge','Test mode' in pg.inner_text('main'))
    pg.click('.opt >> nth=0'); ok('test: no feedback before submit',pg.locator('.feedback').count()==0 and pg.locator('.opt.correct').count()==0)
    ok('test: no submit-answer button, change answer allowed',pg.locator('[data-act=submit]').count()==0)
    pg.click('.opt >> nth=1'); ok('test: answer changed (one selected)',pg.locator('.opt[aria-pressed=true]').count()==1)
    pg.click('[data-act=next]'); pg.click('.opt >> nth=2'); pg.click('[data-act=nav]'); ok('test grid shows 2 answered, 8 unanswered', pg.locator('.navgrid button.answered').count()==2 and pg.locator('.navgrid button:not(.answered)').count()==8)
    pg.click('[data-act=submitTest]'); ok('submit asks to confirm and warns about 8 unanswered','8' in pg.inner_text('.dialog') and 'unanswered' in pg.inner_text('.dialog'))
    pg.click('[data-dlg=yes]'); pg.wait_for_selector('.score'); sc=pg.inner_text('.score').replace('\n',' '); print('   score box:',sc[:90])
    ok('test results page with score out of 10','/ 10' in sc)
    ok('test review reveals answers',pg.locator('.review-item .opt.correct').count()>=10)
    pg.goto(BASE+'#/dashboard'); pg.wait_for_selector('.stats'); ok('test history recorded',pg.locator('text=Test history').count()==1)
    # ---------- Shuffle options keeps answers mapped ----------
    pg.goto(BASE+'#/topic/101-histology/CYTO'); pg.wait_for_selector('form[data-form=start]'); pg.check('input[name=shuffleO]'); pg.check('input[name=shuffleQ]'); pg.click('button:has-text("Start")'); pg.wait_for_selector('.qcard')
    hist=json.load(open(ROOT_DIR+'/data/module-101/histology.json'))['questions']; byq={q['question']:q for q in hist}
    good=0; checked=0
    for i in range(8):
        qt=pg.inner_text('.qtext').strip(); q=byq.get(qt)
        if q is None: pg.click('[data-act=skip]') if pg.locator('[data-act=skip]').count() else None; 
        shown=[pg.inner_text(f'.opt >> nth={k}') for k in range(pg.locator('.opt').count())]
        ct=correct_text(q); idx=next(k for k,t in enumerate(shown) if ct[:20] in t); pg.click(f'.opt >> nth={idx}'); pg.click('[data-act=submit]')
        checked+=1; good+= pg.locator('.feedback.ok').count()
        pg.click('[data-act=next]')
    ok(f'shuffled Qs/options: picking the correct text always scores correct ({good}/{checked})',good==checked)
    # ---------- Search ----------
    pg.goto(BASE+'#/search?q=pterion'); pg.wait_for_selector('.result',timeout=20000); n=pg.locator('.result').count(); print('   search "pterion" results:',n)
    ok('search finds questions and shows subject/subtopic',n>0 and '›' in pg.inner_text('.result >> nth=0'))
    ok('search highlights the keyword',pg.locator('.result mark').count()>0)
    pg.fill('#s-q','Plasmodium'); pg.select_option('#s-y','3'); pg.click('form[data-form=search2] button'); pg.wait_for_selector('.result',timeout=20000)
    ok('filter by year 3 returns only 3rd-year subjects',all(any(s in t for s in ('Microbiology','Parasitology','Pathology','Pharmacology')) for t in pg.locator('.result .where').all_inner_texts()),str(len(pg.locator('.result').all()))+' shown')
    pg.click('.result >> nth=0'); pg.wait_for_selector('.qcard'); ok('clicking a result opens that question in practice',pg.locator('.qcard').count()==1)
    # ---------- under-review (cancelled) question: shown, never scored ----------
    pg.goto(BASE+'#/topic/101-histology/EX2022'); pg.wait_for_selector('form[data-form=start]'); pg.uncheck('input[name=shuffleQ]'); pg.uncheck('input[name=shuffleO]'); pg.click('button:has-text("Start")'); pg.wait_for_selector('.qcard')
    pg.click('[data-act=nav]'); pg.click('.navgrid button >> nth=33'); ok('opened Histology Exam 2022 question 34 (cancelled in the book key)','Question 34' in pg.inner_text('.qnum'))
    before=json.loads(pg.evaluate("localStorage.getItem('medmap.mcqs.v1')"))['answers']
    pg.click('.opt >> nth=0'); pg.click('[data-act=submit]')
    ok('under-review question shows a notice instead of right/wrong',pg.locator('.feedback.warn').count()==1 and 'under review' in pg.inner_text('.feedback'))
    after=json.loads(pg.evaluate("localStorage.getItem('medmap.mcqs.v1')"))['answers']
    ok('under-review answer is not recorded in statistics',len(before)==len(after))
    # ---------- Reset ----------
    pg.goto(BASE+'#/dashboard'); pg.wait_for_selector('[data-act=reset]'); pg.click('[data-act=reset]'); ok('reset asks for confirmation',pg.locator('.dialog').count()==1)
    pg.click('[data-dlg=yes]'); pg.wait_for_selector('.stats'); ok('reset clears progress','0 Attempted' in pg.inner_text('.stats').replace('\n',' '))
    print('\nJS errors:',errs); b.close()
print(f"\n{sum(r for _,r in res)}/{len(res)} checks passed")
