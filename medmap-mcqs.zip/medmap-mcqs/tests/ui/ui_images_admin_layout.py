import os
ROOT_DIR=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from playwright.sync_api import sync_playwright
import sys, json
import os; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from testutil import server
res=[]; errs=[]
def ok(name,cond,extra=''):
    res.append(bool(cond)); print(('PASS' if cond else 'FAIL'),'-',name,extra)
def key(sid): return sid.replace('|','%7C').replace(':','%3A')
with server() as BASE, sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True); pg=ctx.new_page()
    pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None); pg.on('pageerror',lambda e: errs.append(str(e)))
    # --- image question: opens via search-style direct open link
    pg.goto(BASE+'#/open/M102-PHYS-INTRO-Q003'); pg.wait_for_selector('.qimg'); pg.wait_for_function("document.querySelector('.qimg').complete")
    ok('image question renders figure',pg.evaluate("document.querySelector('.qimg').naturalWidth")>100, pg.inner_text('.qnum'))
    ok('image keeps aspect ratio (no distortion)',pg.evaluate("(()=>{const i=document.querySelector('.qimg');return Math.abs(i.clientWidth/i.clientHeight - i.naturalWidth/i.naturalHeight)<0.05})()"))
    pg.click('.qimg'); ok('tapping the figure opens it enlarged',pg.locator('.zoom').count()==1); pg.keyboard.press('Escape'); ok('Escape closes the enlarged figure',pg.locator('.zoom').count()==0)
    pass
    # --- NEU exam figure question with shared figure
    pg.goto(BASE+'#/open/M205-HIST-EX2025-Q112'); pg.wait_for_selector('.qimg'); pg.wait_for_function("document.querySelector('.qimg').complete"); ok('NEU Figure A question shows its figure',pg.evaluate("document.querySelector('.qimg').naturalWidth")>100)
    # --- five option question
    pg.goto(BASE+'#/open/M205-PHYS-HEAR-Q001'); pg.wait_for_selector('.opt'); ok('five-option question shows letters A-E',pg.locator('.opt').count()==5 and pg.locator('.opt .letter').all_inner_texts()==list('ABCDE'))
    # --- keyboard: press e then Enter (60 decibels is the 5th option, correct)
    pg.keyboard.press('e'); ok('keyboard letter selects an option',pg.locator('.opt[aria-pressed=true]').count()==1); pg.keyboard.press('Enter'); ok('Enter submits the answer',pg.locator('.feedback.ok').count()==1,pg.inner_text('.feedback').replace('\n',' '))
    pg.keyboard.press('Enter'); ok('Enter moves to the next question','Question 2' in pg.inner_text('.qnum'))
    pg.keyboard.press('ArrowLeft'); ok('Left arrow goes back','Question 1' in pg.inner_text('.qnum'))
    # --- admin mode
    ok('students do not see admin details by default',pg.locator('.admin').count()==0)
    pg.goto(BASE+'#/settings'); pg.wait_for_selector('[data-setting=admin]'); pg.check('[data-setting=admin]')
    pg.goto(BASE+'#/open/M309-MICRO-EX2324EOM-Q006'); pg.wait_for_selector('.qcard'); pg.click('.opt >> nth=0'); pg.click('[data-act=submit]')
    adm=pg.inner_text('.admin'); print('   admin block:',adm.replace('\n',' | ')[:220])
    ok('admin mode shows answer status and notes for a flagged question','Needs review' in adm and 'Review note' in adm)
    ok('flagged question: shown as under review (not scored)',pg.locator('.feedback.warn').count()==1)
    pg.goto(BASE+'#/open/M309-MICRO-EX2324EOM-Q001'); pg.wait_for_selector('.qcard'); pg.click('.opt >> nth=3'); pg.click('[data-act=submit]')
    ok('admin mode labels independently solved answers','Independently solved' in pg.inner_text('.admin'))
    pg.goto(BASE+'#/settings'); pg.uncheck('[data-setting=admin]')
    # --- tests exclude needs-review questions
    pg.goto(BASE+'#/topic/309-microbiology/EX2324EOM'); pg.wait_for_selector('form[data-form=start]'); pg.check('input[value=test]')
    ok('topic page counts all 64 questions',' 64 questions' in pg.inner_text('main'))
    pg.click('button:has-text("Start")'); pg.wait_for_selector('.qcard'); ok('test excludes the 3 under-review questions (61 of 64)','of 61' in pg.inner_text('.progress-line').replace('\n',' ') or 'of\n61' in pg.inner_text('.progress-line'),pg.inner_text('.progress-line').replace('\n',' ')[:60])
    # --- export / import
    pg.goto(BASE+'#/settings'); pg.wait_for_selector('[data-act=export]')
    with pg.expect_download() as dl: pg.click('[data-act=export]')
    path=dl.value.path(); data=json.load(open(path)); ok('export downloads a progress file',data.get('v')==1 and len(data['answers'])>0,f"{len(data['answers'])} answers")
    pg.click('[data-act=reset]'); pg.click('[data-dlg=yes]'); pg.wait_for_timeout(300)
    pg.set_input_files('input[data-act=import]',path); pg.wait_for_selector('.dialog'); pg.click('[data-dlg=yes]'); pg.wait_for_timeout(300)
    st=json.loads(pg.evaluate("localStorage.getItem('medmap.mcqs.v1')")); ok('import restores progress',len(st['answers'])==len(data['answers']))
    # --- layout: no horizontal overflow on any main page at several widths
    pages=['#/','#/year/1','#/year/3','#/module/309','#/subject/309-pharmacology','#/topic/309-pharmacology/EX2526','#/session/practice%7Csub%3A309-microbiology%3AEX2324EOM','#/dashboard','#/search?q=ribosome','#/settings','#/open/M102-BIOC-RNA-Q017']
    for w,h in ((320,640),(360,740),(390,844),(768,1024),(1280,800)):
        c2=b.new_context(viewport={'width':w,'height':h}); q=c2.new_page(); q.goto(BASE+'#/'); q.wait_for_selector('.year-card'); bad=[]
        for u in pages:
            q.goto(BASE+u); q.wait_for_timeout(350)
            if u.startswith('#/search'): q.wait_for_selector('.result',timeout=20000)
            ow=q.evaluate("document.documentElement.scrollWidth - window.innerWidth")
            if ow>1: bad.append((u,ow))
        ok(f'no horizontal scrolling at {w}px on {len(pages)} pages',not bad,str(bad))
        if w==1280: q.goto(BASE+'#/module/309'); q.wait_for_timeout(400)
        c2.close()
    # --- local file:// shows helpful message
    q=b.new_page(); q.goto('file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','index.html')); q.wait_for_selector('.notice',timeout=5000); ok('opening index.html from disk explains how to run a local server','http.server' in q.inner_text('.notice'))
    print('\nJS errors (excluding the expected file:// fetch failure):',[e for e in errs if 'file://' not in e]); b.close()
print(f"\n{sum(res)}/{len(res)} checks passed")
