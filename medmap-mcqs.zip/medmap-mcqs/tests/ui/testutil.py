import subprocess, time, contextlib, urllib.request, socket
import os
ROOT=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
@contextlib.contextmanager
def server(port=8765):
    p=subprocess.Popen(['python3','-m','http.server',str(port),'--directory',ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    for _ in range(40):
        try: urllib.request.urlopen(f'http://localhost:{port}/',timeout=1); break
        except Exception: time.sleep(.1)
    try: yield f'http://localhost:{port}/'
    finally: p.terminate()
