/* MedMap MCQs – vanilla JS single-page app (hash routing, JSON data, localStorage progress). */
(function (root) {
'use strict';

/* ============================== utilities ============================== */
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => Number(n).toLocaleString('en-US');
const pct = (a, b) => (b ? Math.round(100 * a / b) : 0);
const LETTERS = 'ABCDEFGH';
function shuffle(arr, rnd) {
  rnd = rnd || Math.random; const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; }
  return a;
}
function sampleKeepOrder(arr, n, rnd) {
  const idx = shuffle(arr.map((_, i) => i), rnd).slice(0, n).sort((a, b) => a - b);
  return idx.map(i => arr[i]);
}

/* ============================ question logic ============================ */
// Options that refer to other options ("all of the above", "a and b" …) must keep their order.
const REF_RE = /\b(all|none|both|neither|any)\s+(of\s+)?(the\s+)?(above|these|them|previous|following)\b|\b(above|previous)\b|\b\(?[a-e]\)?\s*(and|&|\+|,|or)\s*\(?[a-e]\)?(\b|$)/i;
function canShuffleOptions(q) {
  return !q.options.some(o => REF_RE.test(o.text) || /^\s*(all|none|both)\.?\s*$/i.test(o.text));
}
function optionOrder(q, doShuffle, rnd) {
  const ids = q.options.map(o => o.id);
  return (doShuffle && canShuffleOptions(q)) ? shuffle(ids, rnd) : ids;
}
function orderedOptions(q, order) {
  const by = {}; q.options.forEach(o => { by[o.id] = o; });
  const ids = (order && order.length === q.options.length && order.every(i => by[i])) ? order : q.options.map(o => o.id);
  return ids.map(i => by[i]);
}
const scorable = q => q.correctOptionId != null;
const subjKeyOf = q => q.module + '-' + String(q.subject).toLowerCase();
const STATUS_LABEL = {'source-verified': 'Source-verified', 'independently-solved': 'Independently solved (not from the book)', 'needs-review': 'Needs review'};

/* ============================== storage ============================== */
const KEY = 'medmap.mcqs.v1';
const DEFAULT_SETTINGS = {admin: false, shuffleQ: false, shuffleO: false};
function blank() { return {v: 1, answers: {}, sessions: {}, recent: [], lastSession: null, tests: [], settings: Object.assign({}, DEFAULT_SETTINGS)}; }
const Store = {
  data: blank(), memoryOnly: false,
  load() {
    try {
      const raw = root.localStorage.getItem(KEY);
      if (raw) { const d = JSON.parse(raw); this.data = Object.assign(blank(), d); }
    } catch (e) { this.memoryOnly = true; }
    this.data.settings = Object.assign({}, DEFAULT_SETTINGS, this.data.settings);
    return this.data;
  },
  save() {
    const ids = Object.keys(this.data.sessions);
    if (ids.length > 40) {
      ids.sort((a, b) => (this.data.sessions[b].updatedAt || 0) - (this.data.sessions[a].updatedAt || 0));
      ids.slice(40).forEach(i => { if (i !== this.data.lastSession) delete this.data.sessions[i]; });
    }
    try { root.localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) { this.memoryOnly = true; }
  },
  /* Record the latest answer for a question. Only questions with a verified/solved key are scored. */
  record(q, sel) {
    if (!scorable(q)) return;
    const prev = this.data.answers[q.id];
    this.data.answers[q.id] = {s: sel, c: sel === q.correctOptionId ? 1 : 0, t: Date.now(), n: (prev ? prev.n : 0) + 1, k: subjKeyOf(q), i: q.subtopicId};
    this.touchRecent(subjKeyOf(q), q.subtopicId);
  },
  touchRecent(k, i) {
    const r = this.data.recent.filter(x => !(x.k === k && x.i === i));
    r.unshift({k, i, t: Date.now()});
    this.data.recent = r.slice(0, 12);
  },
  resetProgress() { const s = this.data.settings; this.data = blank(); this.data.settings = s; this.save(); }
};
/* Overall bank statistics: each question counts once (its latest answer). */
function statsFrom(answers, pred) {
  let attempted = 0, correct = 0, incorrect = 0, attempts = 0;
  for (const id in answers) {
    const e = answers[id]; if (pred && !pred(e)) continue;
    attempted++; attempts += e.n || 1; if (e.c) correct++; else incorrect++;
  }
  return {attempted, correct, incorrect, attempts, accuracy: pct(correct, attempted)};
}

/* ================================ data ================================ */
const Data = {
  manifest: null, subjects: {}, promises: {}, subjMeta: {}, modMeta: {}, yearMeta: {},
  async init() {
    const r = await fetch('data/years.json');
    if (!r.ok) throw new Error('Could not load data/years.json (' + r.status + ')');
    this.manifest = await r.json();
    this.manifest.years.forEach(y => {
      this.yearMeta[y.id] = y;
      y.modules.forEach(m => {
        this.modMeta[m.id] = Object.assign({year: y}, m);
        m.subjects.forEach(s => { this.subjMeta[s.key] = Object.assign({year: y, module: m}, s); });
      });
    });
  },
  load(key) {
    if (this.subjects[key]) return Promise.resolve(this.subjects[key]);
    const meta = this.subjMeta[key]; if (!meta) return Promise.reject(new Error('Unknown subject ' + key));
    if (!this.promises[key]) {
      this.promises[key] = fetch(meta.file).then(r => { if (!r.ok) throw new Error('Could not load ' + meta.file); return r.json(); })
        .then(d => { const byId = {}; d.questions.forEach(q => { byId[q.id] = q; }); return (this.subjects[key] = {questions: d.questions, byId}); });
    }
    return this.promises[key];
  },
  async loadAll(onProgress) {
    const keys = Object.keys(this.subjMeta); let n = 0;
    await Promise.all(keys.map(k => this.load(k).then(() => { n++; if (onProgress) onProgress(n, keys.length); })));
  }
};

/* ============================== sessions ============================== */
const scopeKey = (subjKey, subId) => subId ? 'sub:' + subjKey + ':' + subId : 'subj:' + subjKey;
const sidFor = (mode, scope) => mode + '|' + scope;
function topicTitle(subjKey, subId) {
  const m = Data.subjMeta[subjKey]; if (!m) return '';
  const st = subId && m.subtopics.find(s => s.id === subId);
  return m.name + (st ? ' · ' + st.name : ' · all topics');
}
async function selectQuestions({subjKey, subId, mode, filter, count, shuffleQ}) {
  const d = await Data.load(subjKey); const A = Store.data.answers;
  let qs = d.questions.filter(q => !subId || q.subtopicId === subId);
  if (filter === 'unattempted') qs = qs.filter(q => !A[q.id]);
  else if (filter === 'incorrect') qs = qs.filter(q => A[q.id] && !A[q.id].c);
  else if (filter === 'answered') qs = qs.filter(q => A[q.id]);
  if (mode === 'test') qs = qs.filter(scorable);
  if (shuffleQ) qs = shuffle(qs);
  if (count && count < qs.length) qs = shuffleQ ? qs.slice(0, count) : sampleKeepOrder(qs, count);
  return qs;
}
function newSession({sid, scope, subjKey, subId, mode, title, qs, shuffleQ, shuffleO, filter, startQid}) {
  const opt = {};
  qs.forEach(q => { opt[q.id] = optionOrder(q, shuffleO); });
  const idx = startQid ? Math.max(0, qs.findIndex(q => q.id === startQid)) : 0;
  const s = {id: sid, scope, subjKey, subId: subId || null, mode, title, qids: qs.map(q => q.id), opt, idx, sel: {}, done: {},
    submitted: false, result: null, shuffleQ: !!shuffleQ, shuffleO: !!shuffleO, filter: filter || 'all', createdAt: Date.now(), updatedAt: Date.now()};
  Store.data.sessions[sid] = s; Store.data.lastSession = sid; Store.save();
  return s;
}
async function restartSession(s) {
  const d = await Data.load(s.subjKey);
  let qs = s.qids.map(id => d.byId[id]).filter(Boolean);
  if (s.shuffleQ) qs = shuffle(qs);
  s.qids = qs.map(q => q.id);
  qs.forEach(q => { s.opt[q.id] = optionOrder(q, s.shuffleO); });
  s.idx = 0; s.sel = {}; s.done = {}; s.submitted = false; s.result = null; s.updatedAt = Date.now();
  Store.data.lastSession = s.id; Store.save();
}
const sessionAnswered = s => s.mode === 'test' ? Object.keys(s.sel).length : Object.keys(s.done).length;
function sessionFinished(s) { return s.mode === 'test' ? s.submitted : s.qids.length > 0 && Object.keys(s.done).length >= s.qids.length; }
function sessionTally(s, byId) {
  let correct = 0, wrong = 0, unanswered = 0, total = 0;
  s.qids.forEach(id => {
    const q = byId[id]; if (!q || !scorable(q)) return; total++;
    const revealed = s.mode === 'test' ? s.submitted : s.done[id];
    if (!revealed || !s.sel[id]) { unanswered++; return; }
    if (s.sel[id] === q.correctOptionId) correct++; else wrong++;
  });
  return {correct, wrong, unanswered, total};
}

root.__MM_CORE = {esc, shuffle, canShuffleOptions, optionOrder, orderedOptions, statsFrom, Store, sessionTally, scorable, sampleKeepOrder, pct, subjKeyOf};

/* =============================== UI helpers =============================== */
const $ = id => document.getElementById(id);
let currentSid = null;
function mount(html, opts) {
  const m = $('main'); const keep = opts && opts.keepScroll; const y = root.scrollY;
  m.innerHTML = '<div class="view">' + html + '</div>';
  if (keep) { root.scrollTo(0, y); } else { root.scrollTo(0, 0); m.focus({preventScroll: true}); }
}
function crumbs(items) {
  const el = $('crumbs');
  if (!items || !items.length) { el.innerHTML = ''; return; }
  el.innerHTML = '<ol>' + items.map((c, i) => i === items.length - 1
    ? '<li aria-current="page">' + esc(c.t) + '</li>' : '<li><a href="' + c.h + '">' + esc(c.t) + '</a></li>').join('') + '</ol>';
}
function setNav(name) { ['search', 'dashboard', 'settings'].forEach(n => { const a = $('nav-' + n); if (a) a.classList.toggle('active', n === name); }); }
let toastTimer;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600); }
function confirmDialog({title, body, ok, danger}) {
  return new Promise(resolve => {
    const prev = document.activeElement; const r = $('modal-root');
    r.innerHTML = '<div class="overlay" role="presentation"><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="dlg-t"><h2 id="dlg-t">' + esc(title) + '</h2><p>' + body + '</p>' +
      '<div class="btn-row"><button class="btn secondary" data-dlg="no">Cancel</button><button class="btn' + (danger ? ' danger' : '') + '" data-dlg="yes">' + esc(ok || 'Confirm') + '</button></div></div></div>';
    const done = v => { r.innerHTML = ''; document.removeEventListener('keydown', onKey, true); if (prev && prev.focus) prev.focus(); resolve(v); };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); done(false); } };
    document.addEventListener('keydown', onKey, true);
    r.querySelector('[data-dlg=no]').onclick = () => done(false);
    r.querySelector('[data-dlg=yes]').onclick = () => done(true);
    r.querySelector('.overlay').onclick = e => { if (e.target.classList.contains('overlay')) done(false); };
    r.querySelector('[data-dlg=no]').focus();
  });
}
function zoomImage(src) {
  const r = $('modal-root'); r.innerHTML = '<div class="overlay" role="dialog" aria-modal="true" aria-label="Enlarged figure"><img class="zoom" src="' + esc(src) + '" alt="Enlarged figure"></div>';
  const close = () => { r.innerHTML = ''; document.removeEventListener('keydown', k, true); };
  const k = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', k, true); r.firstChild.onclick = close;
}
function bar(a, b, cls) { return '<div class="bar ' + (cls || '') + '" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct(a, b) + '"><i style="width:' + pct(a, b) + '%"></i></div>'; }
function progressIndex() {
  const subj = {}, sub = {};
  const A = Store.data.answers;
  for (const id in A) {
    const e = A[id]; const s = subj[e.k] || (subj[e.k] = {a: 0, c: 0}); s.a++; if (e.c) s.c++;
    const kk = e.k + '|' + e.i; const t = sub[kk] || (sub[kk] = {a: 0, c: 0}); t.a++; if (e.c) t.c++;
  }
  return {subj, sub};
}
function resumeInfo() {
  const s = Store.data.sessions[Store.data.lastSession];
  if (!s || sessionFinished(s) || !Data.subjMeta[s.subjKey]) return null;
  return s;
}
function resumeCard(s) {
  if (!s) return '';
  return '<div class="card" style="margin-top:1rem"><h3>Continue where you left off</h3><p class="muted small">' + esc(s.title) + ' · ' + (s.mode === 'test' ? 'Test' : 'Practice') + ' · ' + sessionAnswered(s) + ' of ' + s.qids.length + ' answered</p>' +
    '<a class="btn" href="#/session/' + encodeURIComponent(s.id) + '">Resume session</a></div>';
}
function crumbsFor(subjKey, subId, last) {
  const m = Data.subjMeta[subjKey]; const items = [{t: 'Home', h: '#/'}, {t: m.year.name, h: '#/year/' + m.year.id}, {t: m.module.name, h: '#/module/' + m.module.id}, {t: m.name, h: '#/subject/' + subjKey}];
  if (subId) { const st = m.subtopics.find(x => x.id === subId); items.push({t: st ? st.name : subId, h: '#/topic/' + subjKey + '/' + subId}); }
  else if (last) items.push({t: 'All topics', h: '#/topic/' + subjKey + '/all'});
  if (last) items.push({t: last}); else items[items.length - 1] = {t: items[items.length - 1].t};
  return items;
}

/* ================================ views ================================ */
function viewHome() {
  setNav(''); crumbs([]);
  const years = Data.manifest.years;
  mount('<section class="hero"><img src="assets/logo/medmap-logo-circle.png" alt="MedMap Medical Courses logo" width="132" height="132">' +
    '<h1>MedMap MCQs</h1><p>An organized question bank from the MedMap MCQ books. Practise by topic, test yourself, check answers and explanations, and track your progress.</p>' +
    '<form class="searchbar" data-form="search" role="search"><input type="search" name="q" placeholder="Search questions" aria-label="Search questions"><button class="btn" type="submit">Search</button></form></section>' +
    '<h2>Choose your academic year</h2><div class="grid cols3">' +
    years.map(y => '<a class="card year-card" href="#/year/' + y.id + '"><span class="num" aria-hidden="true">' + y.id + '</span><div><h3>' + esc(y.name) + '</h3><div>' +
      y.modules.map(m => '<span class="pill">' + esc(m.name) + '</span>').join('') + '</div><div class="muted small">' + fmt(y.count) + ' questions</div></div></a>').join('') +
    '</div>' + resumeCard(resumeInfo()) +
    '<div class="btn-row" style="justify-content:center"><a class="btn secondary" href="#/dashboard">My progress</a><a class="btn secondary" href="#/search">Search all questions</a></div>');
}
function viewYear(yid) {
  const y = Data.yearMeta[yid]; if (!y) return viewNotFound();
  setNav(''); crumbs([{t: 'Home', h: '#/'}, {t: y.name}]);
  mount('<a class="back" href="#/">‹ Back</a><h1>' + esc(y.name) + '</h1><p class="muted">Choose a module.</p><div class="grid cols2">' +
    y.modules.map(m => '<a class="card" href="#/module/' + m.id + '"><h3>' + esc(m.name) + '</h3><div>' + m.subjects.map(s => '<span class="pill">' + esc(s.name) + '</span>').join('') + '</div><div class="muted small">' + fmt(m.count) + ' questions</div></a>').join('') + '</div>');
}
function viewModule(mid) {
  const m = Data.modMeta[mid]; if (!m) return viewNotFound();
  const P = progressIndex();
  setNav(''); crumbs([{t: 'Home', h: '#/'}, {t: m.year.name, h: '#/year/' + m.year.id}, {t: m.name}]);
  mount('<a class="back" href="#/year/' + m.year.id + '">‹ ' + esc(m.year.name) + '</a><h1>' + esc(m.name) + '</h1><p class="muted">Choose a subject.</p><div class="grid cols2">' +
    m.subjects.map(s => { const p = P.subj[s.key] || {a: 0, c: 0};
      return '<a class="card subject-card" style="--accent:' + s.accent + '" href="#/subject/' + s.key + '"><img src="' + esc(s.cover) + '" alt="Cover of the ' + esc(s.book) + ' book" loading="lazy" width="72"><div style="flex:1;min-width:0"><h3>' + esc(s.name) + '</h3><div class="muted small">' + esc(s.book) + ' book · ' + fmt(s.count) + ' questions · ' + s.subtopics.length + ' topics</div><div style="margin-top:.5rem">' + bar(p.a, s.count) + '<div class="muted small">' + p.a + ' attempted · ' + p.c + ' correct</div></div></div></a>'; }).join('') + '</div>');
}
function viewSubject(key) {
  const s = Data.subjMeta[key]; if (!s) return viewNotFound();
  const P = progressIndex(); setNav('');
  crumbs([{t: 'Home', h: '#/'}, {t: s.year.name, h: '#/year/' + s.year.id}, {t: s.module.name, h: '#/module/' + s.module.id}, {t: s.name}]);
  const groups = []; s.subtopics.forEach(t => { let g = groups.find(x => x.name === t.group); if (!g) groups.push(g = {name: t.group, items: []}); g.items.push(t); });
  mount('<a class="back" href="#/module/' + s.module.id + '">‹ ' + esc(s.module.name) + '</a><div class="page-head"><img class="cover" src="' + esc(s.cover) + '" alt="Cover of the ' + esc(s.book) + ' book" width="78"><div><h1>' + esc(s.name) + '</h1><div class="muted small">' + esc(s.module.name) + ' · ' + esc(s.book) + ' book · ' + fmt(s.count) + ' questions</div></div></div>' +
    '<div class="btn-row"><a class="btn" href="#/topic/' + key + '/all">Practice or test all ' + esc(s.name) + ' questions</a></div>' +
    groups.map(g => '<div class="group-title">' + esc(g.name) + '</div>' + g.items.map(t => { const p = P.sub[key + '|' + t.id] || {a: 0, c: 0};
      return '<a class="card topic" href="#/topic/' + key + '/' + encodeURIComponent(t.id) + '"><div class="t"><b>' + esc(t.name) + '</b><span class="meta">' + fmt(t.count) + ' questions' + (p.a ? ' · ' + p.a + ' attempted · ' + p.c + ' correct' : '') + '</span>' + bar(p.a, t.count) + '</div><span class="chev" aria-hidden="true">›</span></a>'; }).join('')).join(''));
}
async function viewTopic(key, subId) {
  const meta = Data.subjMeta[key]; if (!meta) return viewNotFound();
  const sub = (subId && subId !== 'all') ? subId : null;
  const st = sub && meta.subtopics.find(x => x.id === sub); if (sub && !st) return viewNotFound();
  const T = renderToken; setNav(''); crumbs(crumbsFor(key, sub, 'Start'));
  mount('<p class="loading">Loading questions…</p>');
  let d; try { d = await Data.load(key); } catch (e) { return viewError(e); }
  if (T !== renderToken) return;
  const A = Store.data.answers; const qs = d.questions.filter(q => !sub || q.subtopicId === sub);
  const n = qs.length; const un = qs.filter(q => !A[q.id]).length, inc = qs.filter(q => A[q.id] && !A[q.id].c).length, ans = n - un;
  const sc = qs.filter(scorable).length, cor = qs.filter(q => A[q.id] && A[q.id].c).length;
  const scope = scopeKey(key, sub); const sets = Store.data.settings;
  const ps = Store.data.sessions[sidFor('practice', scope)], ts = Store.data.sessions[sidFor('test', scope)];
  const resumeRow = (s, label) => s ? '<a class="btn secondary small" href="#/' + (sessionFinished(s) ? 'review/' : 'session/') + encodeURIComponent(s.id) + '">' + (sessionFinished(s) ? 'Review last ' + label : 'Resume ' + label + ' (' + sessionAnswered(s) + '/' + s.qids.length + ')') + '</a>' : '';
  const counts = [10, 20, 30, 50, 100].filter(c => c < sc);
  mount('<a class="back" href="#/subject/' + key + '">‹ ' + esc(meta.name) + '</a><h1>' + esc(st ? st.name : 'All ' + meta.name + ' questions') + '</h1>' +
    '<p class="muted">' + esc(meta.name) + ' · ' + esc(meta.module.name) + ' · ' + fmt(n) + ' questions · ' + ans + ' attempted · ' + cor + ' correct</p>' + bar(ans, n) +
    (ps || ts ? '<div class="btn-row">' + resumeRow(ps, 'practice') + resumeRow(ts, 'test') + '</div>' : '') +
    '<form class="card" data-form="start" data-key="' + key + '" data-sub="' + (sub || '') + '" style="margin-top:1rem"><h2 style="margin-top:0">Start a session</h2>' +
    '<div class="field"><label id="l-mode">Mode</label><div class="seg" role="radiogroup" aria-labelledby="l-mode"><label><input type="radio" name="mode" value="practice" checked><span>Practice</span></label><label><input type="radio" name="mode" value="test"><span>Test</span></label></div>' +
    '<p class="small muted" id="mode-help">Practice: submit each answer and see the correct answer and explanation straight away.</p></div>' +
    '<div class="field"><label id="l-filter">Which questions?</label><div class="seg" role="radiogroup" aria-labelledby="l-filter">' +
    [['all', 'All (' + n + ')', n], ['unattempted', 'Unattempted (' + un + ')', un], ['incorrect', 'Incorrect (' + inc + ')', inc], ['answered', 'Answered (' + ans + ')', ans]].map((f, i) => '<label><input type="radio" name="filter" value="' + f[0] + '"' + (i === 0 ? ' checked' : '') + (f[2] === 0 ? ' disabled' : '') + '><span>' + f[1] + '</span></label>').join('') + '</div></div>' +
    '<div class="field test-only" hidden><label for="f-count">Test length</label><select id="f-count" name="count"><option value="">All available (' + sc + ')</option>' + counts.map(c => '<option value="' + c + '">' + c + ' random questions</option>').join('') + '</select><p class="small muted">Test mode hides answers until you submit. Questions whose answer is under review are left out of tests.</p></div>' +
    '<label class="check"><input type="checkbox" name="shuffleQ"' + (sets.shuffleQ ? ' checked' : '') + '> Shuffle questions</label>' +
    '<label class="check"><input type="checkbox" name="shuffleO"' + (sets.shuffleO ? ' checked' : '') + '> Shuffle answer options</label>' +
    '<p class="small muted">Options that refer to each other (for example “all of the above”) are never shuffled, so the meaning stays correct.</p>' +
    '<button class="btn" type="submit">Start</button></form>');
}
function viewNotFound() { setNav(''); crumbs([{t: 'Home', h: '#/'}, {t: 'Not found'}]); mount('<div class="empty"><h1>Page not found</h1><p>We couldn’t find that page.</p><a class="btn" href="#/">Go home</a></div>'); }
function viewError(e) {
  setNav(''); crumbs([]);
  const local = location.protocol === 'file:';
  mount('<div class="notice"><h2 style="margin-top:0">Couldn’t load the question bank</h2><p>' + esc(e && e.message || e) + '</p>' +
    (local ? '<p>You opened this page directly from a file. Browsers block loading JSON files that way. Start a small local server instead, for example <code>python3 -m http.server 8000</code> in this folder, then open <code>http://localhost:8000</code>.</p>' : '<p>Check your connection and reload the page.</p>') + '</div>');
}

/* ============================ question rendering ============================ */
function adminHtml(q) {
  if (!Store.data.settings.admin) return '';
  const bits = ['<b>Admin view</b> · ' + esc(STATUS_LABEL[q.answerStatus] || q.answerStatus), esc(q.sourceBook) + (q.sourcePage ? ' · page ' + q.sourcePage : '') + (q.sourceSection ? ' · ' + esc(q.sourceSection) : ''), 'ID ' + esc(q.id)];
  if (q.sourceKeyOptionId) bits.push('Book key says: ' + esc(q.sourceKeyOptionId) + ' (conflicts with the evidence below, so the question is not scored)');
  if (q.tentativeOptionId) bits.push('Tentative answer (not scored): ' + esc(q.tentativeOptionId));
  if (q.independentOptionId && q.independentOptionId !== q.correctOptionId) bits.push('Independent solution differed: ' + esc(q.independentOptionId));
  if (q.reviewNote) bits.push('Review note: ' + esc(q.reviewNote));
  if (q.answerNote) bits.push(esc(q.answerNote));
  if (q.explanation) bits.push('Explanation source: ' + esc(q.explanationSource || 'unknown'));
  return '<div class="admin">' + bits.join('<br>') + '</div>';
}
function feedbackHtml(q, order, sel) {
  if (!scorable(q)) return '<div class="feedback warn" role="status">The answer to this question is under review, so it isn’t scored.</div>';
  const opts = orderedOptions(q, order); const ci = opts.findIndex(o => o.id === q.correctOptionId);
  const right = sel === q.correctOptionId;
  return '<div class="feedback ' + (right ? 'ok' : 'bad') + '" role="status">' + (right ? '✔ Correct' : (sel ? '✘ Incorrect' : 'Not answered')) +
    '<span class="ans">Correct answer: <b>' + LETTERS[ci] + '.</b> ' + esc(opts[ci].text) + '</span></div>';
}
function questionBlock(q, order, sel, revealed, o) {
  o = o || {}; const opts = orderedOptions(q, order); const ok = scorable(q);
  const list = opts.map((op, i) => {
    let cls = 'opt', mark = '';
    if (revealed && ok) {
      if (op.id === q.correctOptionId) { cls += ' correct'; mark = '<span class="mark">✔ Correct answer</span>'; }
      else if (sel === op.id) { cls += ' wrong'; mark = '<span class="mark">✘ Your answer</span>'; }
    } else if (revealed && sel === op.id) mark = '<span class="mark">Your answer</span>';
    return '<li><button type="button" class="' + cls + '" data-act="pick" data-oid="' + esc(op.id) + '" aria-pressed="' + (!revealed && sel === op.id) + '"' + (revealed || o.readonly ? ' disabled' : '') + '><span class="letter">' + LETTERS[i] + '</span><span class="txt">' + esc(op.text) + '</span>' + mark + '</button></li>';
  }).join('');
  return '<div class="qnum">' + (o.label || 'Question') + '</div><div class="qtext">' + esc(q.question) + '</div>' +
    (q.image ? '<img class="qimg" src="' + esc(q.image) + '" alt="Figure for this question (tap to enlarge)" data-act="zoom" loading="lazy">' : '') +
    '<ul class="options" role="group" aria-label="Answer options">' + list + '</ul>' +
    (revealed && o.feedback !== false ? feedbackHtml(q, order, sel) : '') +
    (revealed && q.explanation ? '<div class="explain"><h4>Explanation' + (q.explanationSource && q.explanationSource !== 'original' ? ' (not from the book)' : '') + '</h4>' + esc(q.explanation) + '</div>' : '') + adminHtml(q);
}

/* ================================ session ================================ */
let showNav = false;
async function viewSession(sid) {
  const T = renderToken; const s = Store.data.sessions[sid];
  if (!s || !Data.subjMeta[s.subjKey]) { setNav(''); crumbs([{t: 'Home', h: '#/'}, {t: 'Session not found'}]); return mount('<div class="empty"><h1>Session not found</h1><p>This session isn’t saved on this device any more.</p><a class="btn" href="#/">Go home</a></div>'); }
  if (s.mode === 'test' && s.submitted) { location.replace('#/review/' + encodeURIComponent(sid)); return; }
  mount('<p class="loading">Loading questions…</p>');
  let d; try { d = await Data.load(s.subjKey); } catch (e) { return viewError(e); }
  if (T !== renderToken) return;
  currentSid = sid; showNav = false; Store.data.lastSession = sid; Store.save();
  renderSession(sid, {});
}
function renderSession(sid, o) {
  o = o || {}; const s = Store.data.sessions[sid]; const d = Data.subjects[s.subjKey]; const byId = d.byId;
  s.idx = Math.min(Math.max(0, s.idx), s.qids.length - 1);
  const q = byId[s.qids[s.idx]]; const total = s.qids.length; const test = s.mode === 'test';
  const revealed = !test && !!s.done[q.id]; const sel = s.sel[q.id]; const answered = sessionAnswered(s); const tally = sessionTally(s, byId);
  crumbs(crumbsFor(s.subjKey, s.subId, test ? 'Test' : 'Practice'));
  const last = s.idx === total - 1;
  const grid = showNav ? '<div class="card" style="margin-top:.8rem"><h3>Questions</h3><div class="navgrid">' + s.qids.map((id, i) => {
    let c = i === s.idx ? 'cur ' : ''; const qq = byId[id];
    if (test) { if (s.sel[id]) c += 'answered'; }
    else if (s.done[id]) c += !scorable(qq) ? 'answered' : (s.sel[id] === qq.correctOptionId ? 'ok' : 'bad');
    return '<button type="button" class="' + c + '" data-act="goto" data-i="' + i + '" aria-label="Question ' + (i + 1) + (c.includes('ok') ? ', correct' : c.includes('bad') ? ', incorrect' : c.includes('answered') ? ', answered' : ', unanswered') + '">' + (i + 1) + '</button>'; }).join('') + '</div>' +
    '<div class="legend">' + (test ? '<span><i class="dot answered"></i>Answered</span><span><i class="dot"></i>Unanswered</span>' : '<span><i class="dot ok"></i>Correct</span><span><i class="dot bad"></i>Incorrect</span><span><i class="dot"></i>Not answered</span>') + '</div></div>' : '';
  const primary = test
    ? '<button class="btn" data-act="next"' + (last ? ' disabled' : '') + '>Next ›</button>'
    : (revealed ? '<button class="btn primary-wide" data-act="' + (last ? 'finish' : 'next') + '">' + (last ? 'Finish ✓' : 'Next question ›') + '</button>'
      : '<button class="btn primary-wide" data-act="submit"' + (sel ? '' : ' disabled') + '>Submit answer</button><button class="btn secondary" data-act="next"' + (last ? ' disabled' : '') + ' aria-label="Skip to next question">Skip ›</button>');
  mount('<div class="qhead"><div><span class="badge' + (test ? ' test' : '') + '">' + (test ? 'Test mode' : 'Practice mode') + '</span> <span class="muted small">' + esc(s.title) + '</span></div></div>' +
    '<div class="progress-line"><span>Question <b>' + (s.idx + 1) + '</b> of <b>' + total + '</b></span><span>Answered <b>' + answered + '</b></span><span>Remaining <b>' + (total - answered) + '</b></span>' +
    (test ? '' : '<span>Correct <b>' + tally.correct + '</b></span>') + '</div>' + bar(answered, total) +
    '<div class="card qcard" style="margin-top:.8rem">' + questionBlock(q, s.opt[q.id], sel, revealed, {label: 'Question ' + (s.idx + 1) + (q.number ? ' · book no. ' + q.number : '')}) + '</div>' +
    '<div class="qnav"><button class="btn secondary" data-act="prev"' + (s.idx === 0 ? ' disabled' : '') + '>‹ Previous</button>' + primary + '</div>' +
    '<div class="btn-row">' + '<button class="btn secondary small" data-act="nav" aria-expanded="' + showNav + '">' + (showNav ? 'Hide' : 'Show') + ' question list</button>' +
    (test ? '<button class="btn small" data-act="submitTest">Submit test</button>' : '<button class="btn secondary small" data-act="review">Review answers</button>') +
    (!test && tally.wrong ? '<button class="btn secondary small" data-act="retry">Retry incorrect (' + tally.wrong + ')</button>' : '') +
    '<button class="btn ghost small" data-act="restart">Restart</button></div>' + grid, {keepScroll: o.keep});
  if (o.focusOid) { const b = document.querySelector('[data-oid="' + o.focusOid + '"]'); if (b) b.focus({preventScroll: true}); }
}
async function sessionAct(act, el) {
  const sid = currentSid; const s = Store.data.sessions[sid]; if (!s) return; const d = Data.subjects[s.subjKey]; const q = d.byId[s.qids[s.idx]];
  const re = o => { s.updatedAt = Date.now(); Store.save(); renderSession(sid, o); };
  if (act === 'pick') { if (s.mode === 'practice' && s.done[q.id]) return; s.sel[q.id] = el.dataset.oid; return re({keep: true, focusOid: el.dataset.oid}); }
  if (act === 'submit') { if (!s.sel[q.id]) return; s.done[q.id] = true; Store.record(q, s.sel[q.id]); return re({keep: true}); }
  if (act === 'next') { if (s.idx < s.qids.length - 1) { s.idx++; re({}); } return; }
  if (act === 'prev') { if (s.idx > 0) { s.idx--; re({}); } return; }
  if (act === 'goto') { s.idx = +el.dataset.i; return re({}); }
  if (act === 'nav') { showNav = !showNav; return renderSession(sid, {keep: true}); }
  if (act === 'finish' || act === 'review') { Store.save(); location.hash = '#/review/' + encodeURIComponent(sid); return; }
  if (act === 'restart') {
    const ok = await confirmDialog({title: 'Restart this ' + s.mode + '?', body: 'Your answers in this session will be cleared and you will start from question 1. Your overall progress and statistics are not changed.', ok: 'Restart', danger: true});
    if (ok) { await restartSession(s); showNav = false; renderSession(sid, {}); toast('Session restarted'); } return;
  }
  if (act === 'retry') return retryIncorrect(s);
  if (act === 'submitTest') return submitTest(s);
}
async function retryIncorrect(s) {
  const d = Data.subjects[s.subjKey];
  const wrong = s.qids.map(id => d.byId[id]).filter(q => q && scorable(q) && s.sel[q.id] && s.sel[q.id] !== q.correctOptionId && (s.mode === 'test' ? s.submitted : s.done[q.id]));
  if (!wrong.length) return toast('No incorrect answers to retry');
  const sid = sidFor('practice', 'retry:' + s.subjKey + ':' + Date.now());
  newSession({sid, scope: 'retry', subjKey: s.subjKey, subId: s.subId, mode: 'practice', title: 'Retry incorrect · ' + s.title, qs: shuffle(wrong), shuffleQ: true, shuffleO: s.shuffleO, filter: 'incorrect'});
  location.hash = '#/session/' + encodeURIComponent(sid);
}
async function submitTest(s) {
  const un = s.qids.length - Object.keys(s.sel).length;
  const ok = await confirmDialog({title: 'Submit test?', body: un ? 'You have <b>' + un + '</b> unanswered question' + (un === 1 ? '' : 's') + '. Unanswered questions count as incorrect.' : 'You answered every question. You can’t change answers after submitting.', ok: 'Submit test'});
  if (!ok) return;
  const d = Data.subjects[s.subjKey]; let correct = 0, answered = 0;
  s.qids.forEach(id => { const q = d.byId[id]; if (!scorable(q) || !s.sel[id]) return; answered++; Store.record(q, s.sel[id]); if (s.sel[id] === q.correctOptionId) correct++; });
  s.submitted = true; s.result = {score: correct, total: s.qids.length, answered, ts: Date.now()};
  Store.data.tests.unshift({id: s.id + '#' + Date.now(), title: s.title, subjKey: s.subjKey, subId: s.subId, score: correct, total: s.qids.length, answered, ts: Date.now()});
  Store.data.tests = Store.data.tests.slice(0, 50); s.updatedAt = Date.now(); Store.save();
  location.hash = '#/review/' + encodeURIComponent(s.id);
}

/* ================================= review ================================= */
let reviewFilter = 'all', reviewSid = null;
async function viewReview(sid) {
  const T = renderToken; const s = Store.data.sessions[sid];
  if (!s || !Data.subjMeta[s.subjKey]) return viewNotFound();
  if (s.mode === 'test' && !s.submitted) { location.replace('#/session/' + encodeURIComponent(sid)); return; }
  mount('<p class="loading">Loading…</p>');
  let d; try { d = await Data.load(s.subjKey); } catch (e) { return viewError(e); }
  if (T !== renderToken) return;
  if (reviewSid !== sid) { reviewSid = sid; reviewFilter = 'all'; }
  renderReview(sid, false);
}
function renderReview(sid, keep) {
  const s = Store.data.sessions[sid]; const d = Data.subjects[s.subjKey]; const test = s.mode === 'test'; const t = sessionTally(s, d.byId);
  crumbs(crumbsFor(s.subjKey, s.subId, test ? 'Test results' : 'Review'));
  const isDone = id => test ? s.submitted : !!s.done[id];
  const rows = s.qids.map((id, i) => ({q: d.byId[id], i})).filter(({q}) => {
    const done = isDone(q.id); const right = done && s.sel[q.id] && s.sel[q.id] === q.correctOptionId;
    if (reviewFilter === 'correct') return done && scorable(q) && right;
    if (reviewFilter === 'incorrect') return done && scorable(q) && s.sel[q.id] && !right;
    if (reviewFilter === 'unanswered') return !done || !s.sel[q.id];
    return test ? true : done;
  });
  const p = pct(t.correct, t.total);
  const summary = test
    ? '<div class="card score ' + (p >= 50 ? 'pass' : 'fail') + '"><div class="muted">Test score</div><div class="big">' + t.correct + ' / ' + t.total + '</div><div class="pct">' + p + '%</div><p class="muted small">' + (s.result ? s.result.answered : 0) + ' answered · ' + t.wrong + ' incorrect · ' + t.unanswered + ' unanswered. This score belongs to this test only; your overall accuracy is on the Progress page.</p></div>'
    : '<div class="card score"><div class="muted">Practice summary</div><div class="big">' + t.correct + ' / ' + (t.correct + t.wrong) + '</div><div class="pct">' + pct(t.correct, t.correct + t.wrong) + '% correct</div><p class="muted small">' + sessionAnswered(s) + ' of ' + s.qids.length + ' questions answered in this session.</p></div>';
  const f = [['all', test ? 'All' : 'Completed'], ['incorrect', 'Incorrect (' + t.wrong + ')'], ['correct', 'Correct (' + t.correct + ')'], ['unanswered', 'Unanswered']];
  mount('<h1>' + (test ? 'Test results' : 'Review answers') + '</h1><p class="muted">' + esc(s.title) + '</p>' + summary +
    '<div class="btn-row">' + (!sessionFinished(s) ? '<a class="btn" href="#/session/' + encodeURIComponent(sid) + '">Resume</a>' : '') +
    (t.wrong ? '<button class="btn" data-act="retryR">Retry incorrect (' + t.wrong + ')</button>' : '') +
    '<button class="btn secondary" data-act="restartR">Restart</button><a class="btn secondary" href="#/topic/' + s.subjKey + '/' + (s.subId ? encodeURIComponent(s.subId) : 'all') + '">Topic page</a></div>' +
    '<div class="seg" role="radiogroup" aria-label="Filter answers">' + f.map(x => '<label><input type="radio" name="rf" value="' + x[0] + '" data-act="rfilter"' + (reviewFilter === x[0] ? ' checked' : '') + '><span>' + x[1] + '</span></label>').join('') + '</div>' +
    (rows.length ? rows.map(({q, i}) => { const done = isDone(q.id);
      const badge = !done || !s.sel[q.id] ? '<span class="badge">Not answered</span>' : !scorable(q) ? '<span class="badge warn">Under review</span>' : s.sel[q.id] === q.correctOptionId ? '<span class="badge ok">Correct</span>' : '<span class="badge bad">Incorrect</span>';
      return '<div class="card review-item">' + badge + questionBlock(q, s.opt[q.id], s.sel[q.id], done, {label: 'Question ' + (i + 1) + (q.number ? ' · book no. ' + q.number : ''), readonly: true, feedback: done}) + '</div>'; }).join('') : '<div class="empty">Nothing to show for this filter.</div>'), {keepScroll: keep});
}
async function reviewAct(act, el) {
  const s = Store.data.sessions[reviewSid]; if (!s) return;
  if (act === 'rfilter') { reviewFilter = el.value; return renderReview(reviewSid, true); }
  if (act === 'retryR') return retryIncorrect(s);
  if (act === 'restartR') {
    const ok = await confirmDialog({title: 'Restart this ' + s.mode + '?', body: 'Your answers in this session will be cleared. Your overall progress and statistics are not changed.', ok: 'Restart', danger: true});
    if (ok) { await restartSession(s); location.hash = '#/session/' + encodeURIComponent(s.id); }
  }
}

/* ================================ dashboard ================================ */
function viewDashboard() {
  setNav('dashboard'); crumbs([{t: 'Home', h: '#/'}, {t: 'My progress'}]);
  const A = Store.data.answers; const st = statsFrom(A); const P = progressIndex(); const total = Data.manifest.total;
  const unit = (a, c, n) => '<span class="sum">' + a + '/' + n + (a ? ' · ' + pct(c, a) + '%' : '') + '</span>';
  const tree = Data.manifest.years.map(y => {
    let ya = 0, yc = 0;
    const mods = y.modules.map(m => {
      let ma = 0, mc = 0;
      const subs = m.subjects.map(s => {
        const p = P.subj[s.key] || {a: 0, c: 0}; ma += p.a; mc += p.c;
        return '<details><summary>' + esc(s.name) + ' ' + unit(p.a, p.c, s.count) + '</summary>' + s.subtopics.map(t => { const q = P.sub[s.key + '|' + t.id] || {a: 0, c: 0};
          return '<div class="row"><a href="#/topic/' + s.key + '/' + encodeURIComponent(t.id) + '">' + esc(t.name) + '</a>' + bar(q.a, t.count, 'acc') + '<span class="sum">' + q.a + '/' + t.count + (q.a ? ' · ' + pct(q.c, q.a) + '%' : '') + '</span></div>'; }).join('') + '</details>'; }).join('');
      ya += ma; yc += mc;
      return '<details><summary>' + esc(m.name) + ' ' + unit(ma, mc, m.count) + '</summary>' + subs + '</details>';
    }).join('');
    return '<details><summary>' + esc(y.name) + ' ' + unit(ya, yc, y.count) + '</summary>' + mods + '</details>';
  }).join('');
  const recent = Store.data.recent.filter(r => Data.subjMeta[r.k]).slice(0, 6).map(r => { const m = Data.subjMeta[r.k]; const t = m.subtopics.find(x => x.id === r.i);
    return '<a class="card topic" href="#/topic/' + r.k + '/' + encodeURIComponent(r.i) + '"><div class="t"><b>' + esc(m.name) + ' · ' + esc(t ? t.name : r.i) + '</b><span class="meta">' + esc(m.module.name) + ' · ' + esc(m.year.name) + '</span></div><span class="chev" aria-hidden="true">›</span></a>'; }).join('');
  const tests = Store.data.tests.slice(0, 8).map(t => '<div class="row" style="border-top:1px solid #eef4f6"><span style="flex:1">' + esc(t.title) + '<br><span class="muted small">' + new Date(t.ts).toLocaleDateString() + '</span></span><b>' + t.score + '/' + t.total + ' (' + pct(t.score, t.total) + '%)</b></div>').join('');
  mount('<h1>My progress</h1>' + resumeCard(resumeInfo()) +
    '<div class="stats" style="margin-top:1rem"><div class="stat"><b>' + fmt(total) + '</b><span>Questions available</span></div><div class="stat"><b>' + fmt(st.attempted) + '</b><span>Attempted (unique)</span></div>' +
    '<div class="stat ok"><b>' + fmt(st.correct) + '</b><span>Correct</span></div><div class="stat bad"><b>' + fmt(st.incorrect) + '</b><span>Incorrect</span></div><div class="stat"><b>' + st.accuracy + '%</b><span>Question-bank accuracy</span></div></div>' +
    '<p class="muted small">Each question counts once, using your latest answer. Question-bank accuracy is separate from the score of an individual test. Questions whose answer is under review are not scored.</p>' +
    (recent ? '<h2>Recently practised</h2>' + recent : '') + '<h2>Progress by year, module, subject and topic</h2><div class="tree">' + tree + '</div>' +
    (tests ? '<h2>Test history</h2><div class="card">' + tests + '</div>' : '') +
    '<div class="notice info" style="margin-top:1.5rem"><b>Where is my progress saved?</b> In this browser, on this device (localStorage). It does not sync between devices or browsers. You can export it from Settings.</div>' +
    '<div class="btn-row"><button class="btn danger" data-act="reset">Reset all progress</button></div>');
}

/* ================================== search ================================== */
let SEARCH = null, searchLimit = 30, lastResults = [], lastTokens = [];
function highlight(text, tokens) {
  if (!tokens.length) return esc(text);
  const re = new RegExp(tokens.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'gi'); let out = '', last = 0, m;
  while ((m = re.exec(text))) { out += esc(text.slice(last, m.index)) + '<mark>' + esc(m[0]) + '</mark>'; last = m.index + m[0].length; if (!m[0].length) re.lastIndex++; }
  return out + esc(text.slice(last));
}
function clip(text, tokens, n) {
  if (text.length <= n) return text; const low = text.toLowerCase(); let at = -1;
  for (const t of tokens) { const i = low.indexOf(t); if (i >= 0) { at = i; break; } }
  const start = Math.max(0, (at < 0 ? 0 : at) - 50); return (start ? '…' : '') + text.slice(start, start + n) + (start + n < text.length ? '…' : '');
}
function buildIndex() {
  SEARCH = [];
  Object.keys(Data.subjMeta).forEach(k => Data.subjects[k].questions.forEach(q => {
    SEARCH.push({q, k, hay: [q.question, q.options.map(o => o.text).join(' '), q.subject, q.subtopic, 'year ' + q.year, 'module ' + q.module].join(' ').toLowerCase()});
  }));
}
function runSearch(p) {
  const tokens = (p.q || '').toLowerCase().split(/\s+/).filter(Boolean); const A = Store.data.answers;
  const res = SEARCH.filter(e => {
    if (p.y && String(e.q.year) !== p.y) return false; if (p.m && e.q.module !== p.m) return false; if (p.s && e.q.subject !== p.s) return false;
    const a = A[e.q.id];
    if (p.st === 'answered' && !a) return false; if (p.st === 'unattempted' && a) return false;
    if (p.st === 'incorrect' && !(a && !a.c)) return false; if (p.st === 'correct' && !(a && a.c)) return false;
    return tokens.every(t => e.hay.indexOf(t) >= 0);
  });
  return {res, tokens};
}
async function viewSearch(params) {
  const T = renderToken; setNav('search'); crumbs([{t: 'Home', h: '#/'}, {t: 'Search'}]);
  const p = {q: params.get('q') || '', y: params.get('y') || '', m: params.get('m') || '', s: params.get('s') || '', st: params.get('st') || ''};
  const years = Data.manifest.years; const mods = []; const subs = [];
  years.forEach(y => y.modules.forEach(m => { mods.push(m); m.subjects.forEach(s => { if (subs.indexOf(s.name) < 0) subs.push(s.name); }); }));
  const sel = (name, label, opts, val) => '<div><label for="s-' + name + '" class="small muted">' + label + '</label><select id="s-' + name + '" name="' + name + '">' + opts.map(o => '<option value="' + esc(o[0]) + '"' + (o[0] === val ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('') + '</select></div>';
  mount('<h1>Search</h1><form class="filters" data-form="search2" role="search"><div class="wide"><label for="s-q" class="small muted">Keywords, subject, topic or scientific term</label><input id="s-q" type="search" name="q" value="' + esc(p.q) + '" placeholder="e.g. brachial plexus, ribosome, Plasmodium"></div>' +
    sel('y', 'Academic year', [['', 'All years']].concat(years.map(y => [String(y.id), y.name])), p.y) + sel('m', 'Module', [['', 'All modules']].concat(mods.map(m => [m.id, m.name])), p.m) +
    sel('s', 'Subject', [['', 'All subjects']].concat(subs.map(s => [s, s])), p.s) + sel('st', 'My progress', [['', 'Any'], ['unattempted', 'Unattempted'], ['answered', 'Answered'], ['incorrect', 'Answered incorrectly'], ['correct', 'Answered correctly']], p.st) +
    '<div class="wide"><button class="btn" type="submit">Search</button></div></form><div id="results"><p class="loading" id="load-p">Loading the question bank…</p></div>');
  try { await Data.loadAll((n, t) => { const el = $('load-p'); if (el) el.textContent = 'Loading the question bank… ' + n + '/' + t; }); } catch (e) { return viewError(e); }
  if (T !== renderToken) return;
  if (!SEARCH) buildIndex(); searchLimit = 30;
  const {res, tokens} = runSearch(p); lastResults = res; lastTokens = tokens; renderResults();
}
function renderResults() {
  const box = $('results'); if (!box) return; const res = lastResults, tokens = lastTokens;
  if (!res.length) { box.innerHTML = '<div class="empty">No questions found. Try fewer or different words, or clear a filter.</div>'; return; }
  box.innerHTML = '<p class="muted" role="status">' + fmt(res.length) + ' question' + (res.length === 1 ? '' : 's') + ' found</p>' + res.slice(0, searchLimit).map(e => {
    const q = e.q; const inQ = tokens.every(t => q.question.toLowerCase().indexOf(t) >= 0);
    let snip = clip(q.question, tokens, 200);
    if (!inQ) { const o = q.options.find(x => tokens.some(t => x.text.toLowerCase().indexOf(t) >= 0)); if (o) snip += ' — option: ' + clip(o.text, tokens, 90); }
    return '<a class="card result" href="#/open/' + encodeURIComponent(q.id) + '"><div class="where">' + esc(q.subject) + ' › ' + esc(q.subtopic) + ' · ' + esc(Data.subjMeta[e.k].module.name) + '</div><div class="snip">' + highlight(snip, tokens) + '</div><div class="muted small">Question ' + (q.number || '') + ' · Year ' + q.year + '</div></a>'; }).join('') +
    (res.length > searchLimit ? '<div class="btn-row" style="justify-content:center"><button class="btn secondary" data-act="more">Show more results</button></div>' : '');
}
const CODE_SUBJ = {ANAT: 'anatomy', HIST: 'histology', BIOC: 'biochemistry', PHYS: 'physiology', MICRO: 'microbiology', PARA: 'parasitology', PATH: 'pathology', PHARM: 'pharmacology'};
async function openQuestion(qid) {
  const m = /^M(\d+)-([A-Z]+)-(.+)-Q\d+$/.exec(qid); const key = m && CODE_SUBJ[m[2]] ? m[1] + '-' + CODE_SUBJ[m[2]] : null;
  if (!key || !Data.subjMeta[key]) return viewNotFound();
  const T = renderToken; mount('<p class="loading">Opening question…</p>');
  let d; try { d = await Data.load(key); } catch (e) { return viewError(e); }
  if (T !== renderToken) return;
  const q = d.byId[qid]; if (!q) return viewNotFound();
  const scope = scopeKey(key, q.subtopicId), sid = sidFor('practice', scope); let s = Store.data.sessions[sid];
  if (s && s.qids.indexOf(qid) >= 0 && !sessionFinished(s)) { s.idx = s.qids.indexOf(qid); }
  else { const qs = d.questions.filter(x => x.subtopicId === q.subtopicId); s = newSession({sid, scope, subjKey: key, subId: q.subtopicId, mode: 'practice', title: topicTitle(key, q.subtopicId), qs, startQid: qid}); }
  Store.data.lastSession = sid; Store.save(); location.replace('#/session/' + encodeURIComponent(sid));
}

/* ================================== settings ================================== */
function viewSettings() {
  setNav('settings'); crumbs([{t: 'Home', h: '#/'}, {t: 'Settings'}]); const s = Store.data.settings;
  mount('<h1>Settings</h1><div class="card"><h3>Practice defaults</h3>' +
    '<label class="check"><input type="checkbox" data-setting="shuffleQ"' + (s.shuffleQ ? ' checked' : '') + '> Shuffle questions by default</label>' +
    '<label class="check"><input type="checkbox" data-setting="shuffleO"' + (s.shuffleO ? ' checked' : '') + '> Shuffle answer options by default</label></div>' +
    '<div class="card" style="margin-top:.9rem"><h3>Admin / reviewer view</h3><p class="muted small">Shows each question’s answer status (source-verified, independently solved or needs review), source book page and review notes. Students don’t need this. It only changes what is shown in this browser.</p>' +
    '<label class="check"><input type="checkbox" data-setting="admin"' + (s.admin ? ' checked' : '') + '> Show admin details on questions</label></div>' +
    '<div class="card" style="margin-top:.9rem"><h3>Your data</h3><p class="muted small">Progress is stored in this browser on this device only (localStorage) and does not sync between devices or browsers. Use export and import to move it yourself.' + (Store.memoryOnly ? ' <b>Your browser is blocking storage, so progress will be lost when you close this page.</b>' : '') + '</p>' +
    '<div class="btn-row"><button class="btn secondary" data-act="export">Export progress</button><label class="btn secondary" style="cursor:pointer">Import progress<input type="file" accept="application/json,.json" data-act="import" hidden></label><button class="btn danger" data-act="reset">Reset all progress</button></div></div>');
}
async function resetProgress() {
  const ok = await confirmDialog({title: 'Reset all progress?', body: 'This permanently deletes your answers, saved sessions and test history on this device. It can’t be undone.', ok: 'Reset everything', danger: true});
  if (!ok) return; Store.resetProgress(); toast('Progress reset'); route();
}
function exportProgress() {
  const blob = new Blob([JSON.stringify(Store.data)], {type: 'application/json'}); const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'medmap-progress-' + new Date().toISOString().slice(0, 10) + '.json'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function importProgress(file) {
  const r = new FileReader();
  r.onload = async () => {
    try { const d = JSON.parse(r.result); if (!d || d.v !== 1 || typeof d.answers !== 'object') throw new Error('bad');
      const ok = await confirmDialog({title: 'Replace your progress?', body: 'The imported file will replace the progress currently saved on this device.', ok: 'Replace', danger: true});
      if (ok) { Store.data = Object.assign(blank(), d); Store.save(); toast('Progress imported'); route(); }
    } catch (e) { toast('That file isn’t a MedMap progress export'); }
  }; r.readAsText(file);
}

/* ================================ router & events ================================ */
let renderToken = 0;
async function route() {
  renderToken++; currentSid = null;
  const raw = (location.hash || '#/').replace(/^#/, ''); const qi = raw.indexOf('?');
  const parts = (qi >= 0 ? raw.slice(0, qi) : raw).split('/').filter(Boolean).map(decodeURIComponent); const params = new URLSearchParams(qi >= 0 ? raw.slice(qi + 1) : '');
  try {
    const [a, b, c] = parts;
    if (!a) return viewHome();
    if (a === 'year') return viewYear(+b);
    if (a === 'module') return viewModule(b);
    if (a === 'subject') return viewSubject(b);
    if (a === 'topic') return viewTopic(b, c);
    if (a === 'session') return viewSession(b);
    if (a === 'review') return viewReview(b);
    if (a === 'open') return openQuestion(b);
    if (a === 'search') return viewSearch(params);
    if (a === 'dashboard') return viewDashboard();
    if (a === 'settings') return viewSettings();
    return viewNotFound();
  } catch (e) { console.error(e); viewError(e); }
}
async function startFromForm(f) {
  const key = f.dataset.key, sub = f.dataset.sub || null; const fd = new FormData(f);
  const mode = fd.get('mode'), filter = fd.get('filter') || 'all', count = +fd.get('count') || 0, shuffleQ = !!fd.get('shuffleQ'), shuffleO = !!fd.get('shuffleO');
  Store.data.settings.shuffleQ = shuffleQ; Store.data.settings.shuffleO = shuffleO; Store.save();
  const qs = await selectQuestions({subjKey: key, subId: sub, mode, filter, count: mode === 'test' ? count : 0, shuffleQ});
  if (!qs.length) return toast('No questions match that choice.');
  const scope = scopeKey(key, sub), sid = sidFor(mode, scope), ex = Store.data.sessions[sid];
  if (ex && sessionAnswered(ex) > 0 && !sessionFinished(ex)) {
    const ok = await confirmDialog({title: 'Replace your saved ' + mode + '?', body: 'You have a saved ' + mode + ' with ' + sessionAnswered(ex) + ' answered question' + (sessionAnswered(ex) === 1 ? '' : 's') + '. Starting a new one replaces it.', ok: 'Start new', danger: true});
    if (!ok) return;
  }
  newSession({sid, scope, subjKey: key, subId: sub, mode, title: topicTitle(key, sub), qs, shuffleQ, shuffleO, filter});
  location.hash = '#/session/' + encodeURIComponent(sid);
}
const SESSION_ACTS = ['pick', 'submit', 'next', 'prev', 'goto', 'nav', 'finish', 'review', 'restart', 'retry', 'submitTest'];
function onClick(e) {
  const el = e.target.closest('[data-act]'); if (!el) return; const act = el.dataset.act;
  if (SESSION_ACTS.indexOf(act) >= 0) { if (currentSid) { e.preventDefault(); sessionAct(act, el); } return; }
  if (act === 'retryR' || act === 'restartR') return reviewAct(act, el);
  if (act === 'zoom') return zoomImage(el.getAttribute('src'));
  if (act === 'more') { searchLimit += 30; return renderResults(); }
  if (act === 'reset') return resetProgress();
  if (act === 'export') return exportProgress();
}
function onChange(e) {
  const el = e.target;
  if (el.dataset.act === 'rfilter') return reviewAct('rfilter', el);
  if (el.dataset.act === 'import' && el.files && el.files[0]) return importProgress(el.files[0]);
  if (el.dataset.setting) { Store.data.settings[el.dataset.setting] = el.checked; Store.save(); toast('Saved'); return; }
  if (el.name === 'mode' && el.form && el.form.dataset.form === 'start') {
    const test = el.value === 'test'; const t = el.form.querySelector('.test-only'); if (t) t.hidden = !test;
    const h = el.form.querySelector('#mode-help'); if (h) h.textContent = test ? 'Test: answers stay hidden until you submit. You can move between questions and change answers before submitting.' : 'Practice: submit each answer and see the correct answer and explanation straight away.';
  }
}
function onSubmit(e) {
  const f = e.target.closest('form[data-form]'); if (!f) return; e.preventDefault(); const kind = f.dataset.form; const fd = new FormData(f);
  if (kind === 'start') return startFromForm(f);
  if (kind === 'search') { const q = (fd.get('q') || '').trim(); location.hash = '#/search' + (q ? '?q=' + encodeURIComponent(q) : ''); return; }
  if (kind === 'search2') { const p = new URLSearchParams(); ['q', 'y', 'm', 's', 'st'].forEach(k => { const v = (fd.get(k) || '').toString().trim(); if (v) p.set(k, v); }); const next = '#/search' + (p.toString() ? '?' + p.toString() : ''); if (location.hash === next) route(); else location.hash = next; }
}
function onKey(e) {
  if (!currentSid || $('modal-root').firstChild) return; const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'select' || tag === 'textarea' || e.ctrlKey || e.metaKey || e.altKey) return;
  const s = Store.data.sessions[currentSid]; if (!s) return;
  if (e.key === 'ArrowRight') { e.preventDefault(); sessionAct('next', document.body); }
  else if (e.key === 'ArrowLeft') { e.preventDefault(); sessionAct('prev', document.body); }
  else if (/^[a-eA-E1-5]$/.test(e.key)) { const i = /\d/.test(e.key) ? +e.key - 1 : e.key.toLowerCase().charCodeAt(0) - 97; const q = Data.subjects[s.subjKey].byId[s.qids[s.idx]];
    const o = orderedOptions(q, s.opt[q.id])[i]; if (o) { const b = document.querySelector('[data-oid="' + o.id + '"]'); if (b && !b.disabled) sessionAct('pick', b); } }
  else if (e.key === 'Enter' && tag === 'button' && e.target.dataset.act === 'pick' && e.target.getAttribute('aria-pressed') === 'true' && s.mode === 'practice' && !s.done[s.qids[s.idx]]) { e.preventDefault(); sessionAct('submit', e.target); }
  else if (e.key === 'Enter' && (tag === 'body' || tag === 'main')) { const b = document.querySelector('.qnav [data-act="submit"]:not([disabled]), .qnav [data-act="next"]:not([disabled]), .qnav [data-act="finish"]'); if (b) { e.preventDefault(); sessionAct(b.dataset.act, b); } }
}
async function init() {
  Store.load();
  try { await Data.init(); } catch (e) { return viewError(e); }
  document.addEventListener('click', onClick); document.addEventListener('change', onChange); document.addEventListener('submit', onSubmit); document.addEventListener('keydown', onKey);
  root.addEventListener('hashchange', route); route();
}

if (typeof document !== 'undefined' && root === root.window) init();
else if (typeof module !== 'undefined') module.exports = root.__MM_CORE;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
