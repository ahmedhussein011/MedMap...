#!/usr/bin/env python3
"""Build data/years.json from the per-subject question files and validate the bank.

Usage:  python3 tools/build_manifest.py
Run it again whenever you add or change a question file.
"""
import json, os, sys
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, 'data')

# The academic hierarchy requested for MedMap MCQs (do not rename without approval).
HIERARCHY = [
    (1, '1st Year', [
        ('101', 'Module 101', [('Anatomy', 'anatomy'), ('Histology', 'histology')]),
        ('102', 'Module 102', [('Biochemistry', 'biochemistry'), ('Physiology', 'physiology')]),
    ]),
    (2, '2nd Year', [
        ('205', 'Module 205', [('Anatomy', 'anatomy'), ('Physiology', 'physiology'), ('Histology', 'histology')]),
    ]),
    (3, '3rd Year', [
        ('309', 'Module 309', [('Microbiology', 'microbiology'), ('Parasitology', 'parasitology')]),
        ('310', 'Module 310', [('Pathology', 'pathology'), ('Pharmacology', 'pharmacology')]),
    ]),
]

# Source book for every module/subject (cover image = first page of the book).
BOOKS = {
    ('101', 'Anatomy'): ('ISK-101', 'ISK_101'), ('101', 'Histology'): ('ISK-101', 'ISK_101'),
    ('102', 'Biochemistry'): ('INT-102', 'INT_102'), ('102', 'Physiology'): ('INT-102', 'INT_102'),
    ('205', 'Anatomy'): ('NEU-205', 'NEU_205'), ('205', 'Physiology'): ('NEU-205', 'NEU_205'), ('205', 'Histology'): ('NEU-205', 'NEU_205'),
    ('309', 'Microbiology'): ('Microbiology', 'Micro'), ('309', 'Parasitology'): ('Parasitology', 'Para'),
    ('310', 'Pathology'): ('Pathology', 'Patho'), ('310', 'Pharmacology'): ('Pharmacology', 'Pharma'),
}
ACCENT = {'ISK_101': '#476a2c', 'INT_102': '#6b3fa0', 'NEU_205': '#8f6d17', 'Micro': '#4c8a14',
          'Para': '#0f7a8f', 'Patho': '#8e3a9c', 'Pharma': '#b64a14'}
STATUSES = {'source-verified', 'independently-solved', 'needs-review'}


def group_of(section):
    s = section or ''
    if s.startswith('Extra'):
        return 'Extra IMP Questions'
    if s.startswith('Exam') or s.startswith('Previous Exam'):
        return 'Previous Exams'
    return 'Chapters'


def main():
    errors, ids, total, status_total = [], set(), 0, Counter()
    years = []
    for yid, yname, modules in HIERARCHY:
        ymods = []
        for mid, mname, subjects in modules:
            msubs = []
            for sname, fname in subjects:
                rel = f'data/module-{mid}/{fname}.json'
                path = os.path.join(ROOT, rel)
                if not os.path.exists(path):
                    errors.append(f'missing file {rel}'); continue
                d = json.load(open(path, encoding='utf-8'))
                subtopics, order = {}, []
                for q in d['questions']:
                    if q['id'] in ids: errors.append(f"duplicate id {q['id']}")
                    ids.add(q['id'])
                    if q['answerStatus'] not in STATUSES: errors.append(f"{q['id']}: bad status {q['answerStatus']}")
                    oids = [o['id'] for o in q['options']]
                    if len(oids) < 2 or len(set(oids)) != len(oids): errors.append(f"{q['id']}: bad options")
                    c = q.get('correctOptionId')
                    if c is None and q['answerStatus'] != 'needs-review': errors.append(f"{q['id']}: no answer but status {q['answerStatus']}")
                    if c is not None and c not in oids: errors.append(f"{q['id']}: answer {c} not in options")
                    if q.get('image') and not os.path.exists(os.path.join(ROOT, q['image'])): errors.append(f"{q['id']}: missing image {q['image']}")
                    if (q['year'], q['module'], q['subject']) != (yid, mid, sname): errors.append(f"{q['id']}: wrong placement")
                    st = subtopics.setdefault(q['subtopicId'], {'id': q['subtopicId'], 'name': q['subtopic'], 'group': group_of(q.get('sourceSection')), 'count': 0, 'review': 0})
                    if q['subtopicId'] not in order: order.append(q['subtopicId'])
                    st['count'] += 1
                    if q['answerStatus'] == 'needs-review': st['review'] += 1
                    status_total[q['answerStatus']] += 1
                    total += 1
                book, cover = BOOKS[(mid, sname)]
                subs_sorted = [subtopics[i] for i in order]
                msubs.append({'key': f'{mid}-{fname}', 'name': sname, 'file': rel, 'book': book,
                              'cover': f'assets/book-covers/{cover}.jpg', 'accent': ACCENT[cover],
                              'count': sum(s['count'] for s in subs_sorted), 'subtopics': subs_sorted})
            ymods.append({'id': mid, 'name': mname, 'subjects': msubs,
                          'count': sum(s['count'] for s in msubs)})
        years.append({'id': yid, 'name': yname, 'modules': ymods, 'count': sum(m['count'] for m in ymods)})
    out = {'generated': True, 'total': total, 'years': years}
    json.dump(out, open(os.path.join(DATA, 'years.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'questions: {total}  statuses: {dict(status_total)}')
    for y in years:
        print(f"  {y['name']}: {y['count']}")
        for m in y['modules']:
            print(f"    {m['name']}: {m['count']}  ->  " + ', '.join(f"{s['name']} {s['count']}" for s in m['subjects']))
    if errors:
        print('\nVALIDATION ERRORS:'); [print(' -', e) for e in errors[:50]]; sys.exit(1)
    print('validation OK')

if __name__ == '__main__':
    main()
