#!/usr/bin/env python3
"""Generate docs/manual-review.md and docs/independently-solved.csv from the question files."""
import csv, glob, json, os
from collections import Counter, defaultdict
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
qs = []
for f in sorted(glob.glob(os.path.join(ROOT, 'data', 'module-*', '*.json'))):
    qs += json.load(open(f, encoding='utf-8'))['questions']

def opt_text(q, oid):
    return next((o['text'] for o in q['options'] if o['id'] == oid), '')

status = Counter(q['answerStatus'] for q in qs)
by_subj = defaultdict(Counter)
for q in qs:
    by_subj[f"Module {q['module']} – {q['subject']}"][q['answerStatus']] += 1

L = ['# MedMap MCQs – manual review list', '',
     f"Generated from the question files. Total questions: **{len(qs):,}**.", '',
     '| Answer status | Questions |', '|---|---:|']
for k in ('source-verified', 'independently-solved', 'needs-review'):
    L.append(f'| {k} | {status[k]:,} |')
L += ['', '* **source-verified** – the answer was read from the book’s own answer key (including key images), or taken from an identical keyed question elsewhere in the same book.',
      '* **independently-solved** – the book has no key for that question; the answer was worked out with medical knowledge. These are listed in `independently-solved.csv` for instructors to check. They are never presented as coming from the book.',
      '* **needs-review** – the answer is ambiguous, cancelled, listed twice, or contradicted elsewhere in the book. These questions are shown to students but are **not scored**.', '',
      '## Status by subject', '', '| Subject | Source-verified | Independently solved | Needs review |', '|---|---:|---:|---:|']
for k in sorted(by_subj):
    c = by_subj[k]; L.append(f"| {k} | {c['source-verified']:,} | {c['independently-solved']:,} | {c['needs-review']:,} |")

L += ['', '## 1. Questions that need review (not scored)', '', '| Question ID | Book page | Reason | Tentative answer (not scored) |', '|---|---:|---|---|']
for q in qs:
    if q['answerStatus'] == 'needs-review':
        t = q.get('tentativeOptionId'); tt = f"{t}. {opt_text(q, t)[:60]}" if t else '—'
        L.append(f"| {q['id']} | {q.get('sourcePage','')} | {(q.get('reviewNote') or '').replace('|','/')} | {tt.replace('|','/')} |")

L += ['', '## 2. Scored questions with a reviewer note', '',
      'These keep their answer but carry a note: a printing defect that was reconstructed, or a solved answer that needs a second look.', '',
      '| Question ID | Book page | Note |', '|---|---:|---|']
for q in qs:
    if q['answerStatus'] != 'needs-review' and q.get('reviewNote'):
        L.append(f"| {q['id']} | {q.get('sourcePage','')} | {q['reviewNote'].replace('|','/')} |")

L += ['', '## 3. Other things to know', '',
      '* Figure-matching exercises (“Match column A with column B”, 11 in the NEU-205 book) are **not MCQs** and are not in the question bank. Their pages are saved in `assets/extra-content/` for the planned “Figure Matching” section.',
      '* No explanations exist in the books, so the explanation field is empty for every question.',
      '* Answers that were read from key images were transcribed by reading the images; spot-checks against medical knowledge found no mismatches, but a second human read of the keys is recommended.', '']
open(os.path.join(ROOT, 'docs', 'manual-review.md'), 'w', encoding='utf-8').write('\n'.join(L))

with open(os.path.join(ROOT, 'docs', 'independently-solved.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh); w.writerow(['id', 'subject', 'subtopic', 'book_number', 'source_page', 'chosen_answer', 'chosen_answer_text', 'question'])
    for q in qs:
        if q['answerStatus'] == 'independently-solved':
            w.writerow([q['id'], q['subject'], q['subtopic'], q.get('number'), q.get('sourcePage'), q['correctOptionId'], opt_text(q, q['correctOptionId']), q['question']])
print(dict(status), '-> docs/manual-review.md, docs/independently-solved.csv')
