import re,json
KEYS={}; EXTRA={}
def put(name,s,n):
    d={}
    for num,l in re.findall(r'(\d+)\s+([a-gX?])',s): d[int(num)]=l
    assert sorted(d)==list(range(1,n+1)),(name,sorted(set(range(1,n+1))-set(d)),len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
put('exam2025',"""1 a,2 d,3 b,4 a,5 b,6 b,7 c,8 b,9 b,10 b,11 c,12 b,13 c,14 d,15 c,16 d,17 b,18 d,19 b,20 c,21 c,22 c,23 d,24 d,25 c,26 d,27 d,28 c,29 c,30 c,
31 a,32 d,33 a,34 a,35 b,36 b,37 d,38 c,39 c,40 b,41 a,42 c,43 c,44 b,45 c,46 d,47 d,48 a,49 d,50 c,51 a,52 a,53 b,54 d,55 d,56 a,57 d,58 c,59 a,60 d,
61 a,62 b,63 c,64 b,65 b,66 d,67 b,68 d,69 d,70 a,71 d,72 a,73 b,74 d,75 a,76 c,77 a,78 a,79 a,80 b,81 c,82 b,83 d,84 c,85 a,86 c,87 c,88 b,89 d,90 d,
91 b,92 c,93 d,94 c,95 a,96 a,97 d,98 d,99 c,100 a,101 b,102 d,103 a,104 b,105 d,106 b,107 b,108 b,109 d,110 a,111 a,112 b,113 d,114 d,115 c""",115)
EXTRA['exam2025_matching']="1 f,2 d,3 a,4 g,5 b"
put('exam2024',"""1 a,2 b,3 c,4 c,5 d,6 d,7 a,8 c,9 b,10 c,11 d,12 a,13 b,14 b,15 d,16 d,17 c,18 a,19 b,20 d,21 a,22 c,23 b,24 a,25 b,26 a,27 c,28 a,29 c,30 d,
31 b,32 d,33 c,34 a,35 a,36 b,37 c,38 d,39 d,40 a,41 a,42 c,43 b,44 d,45 a,46 c,47 b,48 d,49 d,50 c,51 a,52 b,53 d,54 c,55 a,56 b,57 a,58 c,59 c,60 a,
61 b,62 b,63 c,64 a,65 d,66 a,67 b,68 c,69 b,70 d,71 b,72 c,73 a,74 b,75 a,76 b,77 a,78 b,79 a,80 a,81 b,82 a,83 b,84 b,85 b,86 a,87 d,88 c,89 b,90 a,
91 d,92 c,93 d,94 a,95 d,96 d,97 b,98 a,99 c,100 c,101 d,102 d,103 b,104 a,105 a,106 c,107 a,108 b,109 b,110 a,111 c,112 c,113 a,114 c,115 c""",115)
EXTRA['exam2024_matching']="1 g,2 f,3 a,4 e,5 c"
put('ex_anat',"""1 c,2 b,3 b,4 c,5 d,6 d,7 c,8 a,9 d,10 b,11 a,12 d,13 c,14 d,15 b,16 b,17 b,18 c,19 b,20 b,21 b,22 a,23 b,24 c,25 b,26 d,27 c,28 d,29 d,30 b,31 b,32 c,
33 b,34 d,35 a,36 d,37 a,38 b,39 a,40 c,41 c,42 d,43 d,44 d,45 a,46 b,47 c,48 b,49 d,50 c,51 d,52 b,53 c,54 c,55 a,56 a,57 d,58 c,59 d,60 c,61 c,62 d,63 d,64 b,
65 d,66 a,67 c,68 a,69 c,70 c,71 c,72 d,73 d,74 c,75 a,76 a,77 d,78 b,79 c,80 d,81 c,82 c,83 b,84 a,85 b,86 b,87 d,88 a,89 a,90 a,91 d,92 b,93 d,94 b,95 a,96 a,
97 d,98 b,99 a,100 c,101 b,102 c,103 d,104 b,105 d,106 c,107 c,108 d,109 b,110 d,111 b,112 a,113 b,114 a,115 c,116 a,117 a,118 b""",118)
put('ph_sens',"""1 a,2 a,3 b,4 d,5 a,6 b,7 b,8 d,9 b,10 d,11 d,12 c,13 b,14 b,15 c,16 c,17 d,18 a,19 a,20 b,21 d,22 d,23 a,24 b,
25 c,26 d,27 c,28 a,29 c,30 b,31 b,32 a,33 b,34 c,35 c,36 a,37 d,38 d,39 d,40 c,41 c,42 d,43 a,44 b,45 a,46 c,47 d,48 c,
49 a,50 d,51 c,52 c,53 c,54 b,55 b,56 a,57 b,58 c,59 a,60 b,61 b,62 a,63 d,64 d,65 b,66 d,67 d,68 b,69 c,70 c,71 b,72 b""",72)
put('ph_motor',"""1 b,2 d,3 c,4 b,5 b,6 a,7 d,8 b,9 c,10 a,11 a,12 a,13 d,14 b,15 a,16 a,17 b,18 a,19 b,20 a,21 b,22 a,23 c,
24 c,25 b,26 c,27 a,28 c,29 a,30 a,31 d,32 c,33 b,34 d,35 d,36 c,37 c,38 d,39 a,40 d,41 d,42 c,43 a,44 c,45 b,46 a,
47 b,48 d,49 b,50 c,51 d,52 d,53 d,54 a,55 d,56 d,57 d,58 a,59 d,60 d,61 a,62 b,63 b,64 d,65 a,66 b,67 c,68 a""",68)
put('ph_vision',"""1 d,2 d,3 c,4 c,5 b,6 d,7 b,8 d,9 b,10 a,11 b,12 b,13 b,14 a,15 c,16 b,17 d,18 b,19 c,20 b,21 d,22 d,23 d,24 b,25 a,26 d,
27 c,28 d,29 c,30 d,31 c,32 c,33 e,34 c,35 a,36 c,37 e,38 c,39 e,40 b,41 b,42 c,43 b,44 b,45 c,46 e,47 a,48 b,49 c,50 a,51 d""",51)
put('ph_hear',"""1 e,2 b,3 c,4 d,5 a,6 d,7 a,8 a,9 c,10 b,11 a,12 a,13 d,14 a,15 c,16 d,17 d,18 d,19 c,20 a""",20)
put('hi_nerv',"""1 b,2 a,3 b,4 b,5 c,6 c,7 b,8 c,9 c,10 d,11 a,12 a,13 c,14 b,15 b,16 a,17 b,18 d,19 d,20 d,21 d,22 b,23 c,24 d,25 b,26 c,27 b,28 d""",28)
put('hi_cns',"""1 c,2 c,3 b,4 c,5 b,6 d,7 a,8 a,9 d,10 c,11 c,12 c,13 d,14 a,15 c,16 a,17 a,18 a,19 b,20 b,21 d,22 a,23 d,24 a,25 b,26 b,27 a,28 b,29 c,30 b,31 d,32 c""",32)
put('hi_eye',"""1 d,2 d,3 b,4 d,5 d,6 c,7 a,8 d,9 c,10 a,11 b,12 a,13 d,14 a,15 d,16 c,17 a,18 a,19 d,20 c,21 c,22 c,23 b""",23)
put('hi_ear',"""1 a,2 c,3 a,4 a,5 c,6 d,7 d,8 b,9 a,10 c,11 a,12 c,13 d,14 c,15 a,16 d,17 d,18 c,19 b,20 c,21 d,22 c,23 a""",23)
if __name__=="__main__": json.dump({'KEYS':KEYS,'EXTRA':EXTRA},open('neu_keys.json','w')); print({k:len(v) for k,v in KEYS.items()})
