import re,json
KEYS={}; NOTES={}
def put(name,s,n):
    d={}
    for num,l in re.findall(r'(\d+)\s+([a-ex])',s): d[int(num)]=l
    assert sorted(d)==list(range(1,n+1)),(name,sorted(set(range(1,n+1))-set(d)),len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
put('ch_resp',"""1 b,2 d,3 d,4 b,5 d,6 c,7 d,8 a,9 a,10 b,11 c,12 d,13 c,14 c,15 b,16 b,17 a,18 c,19 b,20 b,21 d,22 a,23 c,24 a,
25 d,26 a,27 c,28 d,29 a,30 b,31 a,32 a,33 c,34 c,35 a,36 d,37 c,38 b,39 d,40 c,41 c,42 b,43 c,44 b,45 b,46 a,47 c""",47)
put('ch_git',"""1 c,2 b,3 d,4 a,5 c,6 d,7 b,8 b,9 d,10 b,11 a,12 b,13 b,14 d,15 c,16 c,17 a,18 c,19 c,20 b,21 d,22 d,23 c,24 b,
25 b,26 c,27 d,28 d,29 b,30 c,31 a,32 b,33 c,34 d,35 d,36 c,37 d,38 c,39 c,40 b,41 d,42 a,43 b,44 d,45 c,46 b,47 a""",47)
put('ch_liver',"""1 c,2 c,3 b,4 c,5 c,6 d,7 c,8 d,9 c,10 a,11 a,12 c,13 b,14 c,15 c,16 c,17 d,18 b,19 d,20 b,21 b,22 c,23 c,24 d,25 c,26 b,27 c,28 a""",28)
put('ch_renal',"""1 d,2 c,3 b,4 d,5 b,6 c,7 x,8 c,9 a,10 d,11 a,12 x,13 b,14 d,15 c,16 d,17 b,18 b,19 b,20 c,21 c,22 c,23 c,24 d,
25 c,26 b,27 c,28 d,29 b,30 d,31 d,32 d,33 c,34 c,35 c,36 c,37 b,38 d,39 c,40 a,41 c,42 a,43 c,44 a,45 d,46 b,47 b""",47)
NOTES['ch_renal']={7:"Source key lists two accepted answers for this question (a & d).",12:"Source key lists two accepted answers for this question (a & b)."}
put('ch_male',"""1 b,2 b,3 a,4 a,5 b,6 a,7 d,8 d,9 d,10 c,11 c,12 c,13 b,14 d,15 a,16 d,17 b,18 c,19 a,20 c,21 c,22 b,23 b,24 c""",24)
put('ch_female',"""1 a,2 d,3 d,4 c,5 c,6 a,7 d,8 c,9 d,10 b,11 a,12 d,13 d,14 a,15 d,16 c,17 b,18 b,19 b,20 a,21 a,22 c,23 c,24 b,25 b,26 d""",26)
put('ch_breast',"""1 a,2 c,3 b,4 d,5 c,6 a,7 b,8 b,9 c,10 c,11 c,12 d""",12)
put('ch_skin',"""1 b,2 a,3 b,4 d,5 b,6 c,7 a,8 d,9 c,10 b,11 d,12 c,13 b,14 c,15 d,
16 d,17 b,18 a,19 b,20 a,21 b,22 c,23 d,24 b,25 c,26 a,27 b,28 b,29 c,30 a,
31 c,32 d,33 b,34 b,35 d,36 d,37 b,38 c,39 a,40 a,41 b,42 b,43 b,44 c,45 a,
46 c,47 b,48 a,49 b,50 c,51 d,52 a,53 a,54 d,55 d,56 a,57 b,58 b""",58)
put('ch_bone',"""1 c,2 c,3 c,4 c,5 a,6 a,7 c,8 b,9 b,10 d,11 b,12 c,13 c,14 a,15 b,16 b,17 c,18 c""",18)
put('ch_blood',"""1 c,2 a,3 a,4 a,5 c""",5)
put('ch_endo',"""1 c,2 b,3 c,4 a,5 b,6 c,7 d,8 b,9 b,10 c,11 b,12 b,13 d,14 c,15 a,16 b,17 a,18 c,19 c,20 a,
21 c,22 d,23 b,24 b,25 c,26 c,27 b,28 a,29 d,30 b,31 a,32 d,33 c,34 d,35 a,36 c,37 d,38 c""",38)
put('ch_cns',"""1 b,2 a,3 c,4 c,5 b,6 a,7 d,8 a,9 c,10 c,11 b,12 b,13 d,14 d,15 c,16 c,17 c,18 d,19 c,20 c,
21 b,22 b,23 c,24 a,25 b,26 d,27 c,28 c,29 d,30 a,31 c,32 a,33 d,34 d,35 b,36 b,37 c""",37)
put('exam2324',"""1 b,2 a,3 c,4 c,5 c,6 b,7 c,8 c,9 d,10 b,11 d,12 a,13 b,14 c,15 b,
16 c,17 c,18 a,19 b,20 a,21 d,22 c,23 b,24 d,25 d,26 b,27 d,28 b,29 c,30 c,
31 c,32 b,33 c,34 b,35 b,36 b,37 c,38 c,39 d,40 b,41 c,42 c,43 b,44 b,45 b,
46 d,47 c,48 c,49 b,50 d,51 a,52 a,53 a,54 c,55 b,56 b,57 c,58 c,59 d,60 a""",60)
#PUT_MORE
if __name__=="__main__": json.dump({'KEYS':KEYS,'NOTES':NOTES},open('patho_keys.json','w')); print({k:len(v) for k,v in KEYS.items()})
