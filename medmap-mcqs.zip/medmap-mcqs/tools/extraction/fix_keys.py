import re
from isk_keys import KEYS
def idx(s):
    d={}
    for n,l in re.findall(r'(\d+)\s+([a-d])',s): d[int(n)]=l
    return d
ul = """1 d,2 c,3 a,4 c,5 b,6 d,7 d,8 b,9 d,10 b,11 d,12 d,13 b,14 c,15 b,16 d,17 c,18 a,19 d,20 a,21 b,22 a,23 a,24 a,25 b,26 c,
27 b,28 b,29 c,30 a,31 b,32 d,33 c,34 c,35 a,36 c,37 a,38 d,39 c,40 b,41 b,42 a,43 c,44 c,45 d,46 c,47 d,48 b,49 c,50 a,51 b,
52 d,53 b,54 d,55 c,56 d,57 c,58 c,59 c,60 b,61 b,62 b,63 b,64 b,65 c,66 c,67 b,68 b,69 a,70 a,71 a,72 a,73 d,74 a,75 c,76 d,
77 c,78 d,79 b,80 b,81 d,82 c,83 d,84 d,85 c,86 c,87 d,88 d,89 d,90 d,91 c,92 b,93 c,94 c,95 c,96 d,97 d,98 b,99 b,100 d,101 a,
102 c,103 c,104 c,105 a,106 b,107 a,108 a,109 d,110 a,111 b,112 c,113 a,114 c,115 a,116 a,117 c,118 a,119 c,120 d,121 b,122 c,123 b,124 d,125 d,126 a,
127 c,128 a,129 d,130 b,131 b,132 d,133 d,134 c,135 d,136 b,137 b,138 a,139 c,140 b,141 c,142 b,143 b,144 a,145 b,146 a,147 b,148 c,149 b,150 a,151 b,
152 a,153 a,154 c,155 c,156 a,157 a,158 a,159 a,160 a,161 b,162 d,163 b,164 b,165 c,166 a,167 a,168 b,169 d,170 d,171 d,172 c,173 a,174 b,175 c,176 d,
177 c,178 c,179 c,180 a,181 d,182 b,183 b,184 c,185 c,186 d,187 d,188 a,189 c,190 d,191 d,192 c,193 c,194 b,195 b,196 c,197 a,198 b,199 d,200 a,201 d"""
emb = """1 c,2 d,3 a,4 b,5 a,6 c,7 a,8 d,9 d,10 c,11 b,12 c,13 a,14 a,15 d,16 c,17 a,18 c,19 b,20 a,21 b,22 d,23 b,24 c,25 a,26 a,27 c,28 c,29 b,30 a,31 b,32 d,33 c,34 b,35 c,36 a,37 c,38 d,39 a,40 c,41 a,42 c,43 a,44 b,45 a,46 b,47 c,48 a,49 b,50 b,51 c,52 b,53 a,54 c,55 d,56 b,57 b,58 a,59 b,60 d,61 b,62 a,63 a,64 a,65 b,66 c,67 d,68 a,69 b,70 c,71 c,72 a,73 c,74 b,75 a,76 a,77 b,78 c,79 d,80 a,81 c,82 a,83 b,84 a,85 d,86 a,87 c,88 b"""
cy = """1 b,2 d,3 a,4 c,5 d,6 c,7 d,8 b,9 a,10 c,11 b,12 d,13 a,14 d,15 a,16 d,17 a,18 a,19 b,20 c,21 b,22 c,23 d,24 d,25 d,26 c,27 d,28 d,29 d,30 b,31 a,32 c,33 d,34 a,35 d,36 a,37 b,38 a,39 c,40 b,41 b,42 a,43 d,44 a,45 c,46 d,47 b,48 d,49 b,50 d,51 c,52 a,53 b,54 c,55 a"""
for name,s,n in [("extra_anat_ul",ul,201),("extra_anat_emb",emb,88),("extra_hist_cyto",cy,55)]:
    d=idx(s); assert sorted(d)==list(range(1,n+1)),(name,len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
# sanity: all keys valid letters
import json
for n,v in KEYS.items(): print(n,len(v),set(v))
json.dump(KEYS,open('isk_keys.json','w'))
