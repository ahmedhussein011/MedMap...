import re, json
pages=open('pharma.txt').read().split('\f')
qre=re.compile(r'^\s*(\d+)\s*[\.\-]\s*(.*)')
ore=re.compile(r'^\s*([a-eA-E])\s*[\.\)\-]\s*(.*)')
out=[]; cur=None; sect=None; prevkey=None
for pn in range(3,90):
    lines=pages[pn-1].split('\n')
    L=[l.strip() for l in lines if l.strip()]
    if not L: continue
    hdr=L[0]; ctx=hdr.split('|',1)[1].strip() if '|' in hdr else ''
    for l in L[1:3]:
        m=re.match(r'^Section (\d)',l)
        if m: sect=int(m.group(1))
    if pn>=71: sect='exam'
    key=(ctx,sect)
    if key!=prevkey: cur=None; prevkey=key
    for line in lines:
        s=line.strip()
        if not s or s==hdr or re.match(r'^\d+ \| P a g e',s) or s.startswith('Section ') or s.startswith('* The rate'): continue
        m=ore.match(line)
        if m and cur is not None and len(cur['opts'])<5 and m.group(1).lower()=='abcde'[len(cur['opts'])]:
            cur['opts'].append(m.group(2).strip()); cur['_last']='o'; continue
        m2=re.match(r'^\s*([a-e])\s+(\S.*)',line)
        if m2 and cur is not None and 0<=len(cur['opts'])<5 and m2.group(1)=='abcde'[len(cur['opts'])] and (len(cur['opts'])>0 or cur['_last']=='q') and len(m2.group(1))==1 and not line.strip()[0].isupper():
            cur['opts'].append(m2.group(2).strip()); cur['_last']='o'; continue
        m=qre.match(line)
        if m and (cur is None or len(cur['opts'])>=2):
            cur={'ctx':ctx,'sect':sect,'num':int(m.group(1)),'q':m.group(2).strip(),'opts':[],'page':pn,'_last':'q'}; out.append(cur); continue
        if cur is not None:
            if cur['_last']=='q': cur['q']+=' '+s
            else: cur['opts'][-1]+=' '+s
for q in out:
    if len(q['opts'])<4:
        i=0
        while i<len(q['opts']) and len(q['opts'])<5:
            nxt='abcde'[i+1]
            m=re.search(r'\s+'+nxt+r'\s*\.\s+',q['opts'][i],re.I)
            if m:
                a,b=q['opts'][i][:m.start()],q['opts'][i][m.end():]
                q['opts'][i]=a.strip(); q['opts'].insert(i+1,b.strip()); q['_split']=True
            i+=1
json.dump(out,open('pharma_raw.json','w'),ensure_ascii=False)
from collections import OrderedDict
c=OrderedDict()
for q in out: c[(q['ctx'],q['sect'])]=c.get((q['ctx'],q['sect']),0)+1
for k,v in c.items(): print(k,v)
print('total',len(out),{n:sum(len(q['opts'])==n for q in out) for n in range(0,7)})
print('odd:',[(q['ctx'],q['sect'],q['num'],len(q['opts'])) for q in out if len(q['opts']) not in (4,5)][:30])
from itertools import groupby
for (cx,sc),g in groupby(out,key=lambda x:(x['ctx'],x['sect'])):
    nums=[x['num'] for x in g]
    if nums!=list(range(1,len(nums)+1)): print('seq',cx,sc,[(i,n) for i,n in enumerate(nums,1) if n!=i][:3])
