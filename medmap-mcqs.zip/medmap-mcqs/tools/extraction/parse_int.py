import re, json
pages=open('int.txt').read().split('\f')
SECTIONS=[("exam2025",3,18),("exam2024",19,34),("exam2022",35,50),("extra_phys",51,74),("extra_bio",75,124)]
qre=re.compile(r'^\s*(\d+)\s*\.\s*(.*)')
ore=re.compile(r'^\s*([a-d])\s*[\.\)\-]\s*(.*)')
out=[]
for sid,a,b in SECTIONS:
    cur=None; head=None
    for pn in range(a,b+1):
        for line in pages[pn-1].split('\n'):
            s=line.strip()
            if not s or re.match(r'^INT - 102 \|',s) or re.match(r'^\d+ \| P a g e',s): continue
            if s.startswith('➢'):
                head=s.lstrip('➢ ').strip(); cur=None; continue
            m=ore.match(line)
            if m and cur is not None and len(cur['opts'])<4 and m.group(1)=='abcd'[len(cur['opts'])]:
                cur['opts'].append(m.group(2).strip()); cur['_last']='o'; continue
            m=qre.match(line)
            if m and (cur is None or len(cur['opts'])>=2):
                cur={'sid':sid,'head':head,'num':int(m.group(1)),'q':m.group(2).strip(),'opts':[],'page':pn,'_last':'q'}; out.append(cur); continue
            if cur is not None:
                if cur['_last']=='q': cur['q']+=' '+s
                else: cur['opts'][-1]+=' '+s
json.dump(out,open('int_raw.json','w'),ensure_ascii=False)
from collections import Counter, OrderedDict
c=OrderedDict()
for q in out: c[(q['sid'],q['head'])]=c.get((q['sid'],q['head']),0)+1
for k,v in c.items(): print(k,v)
print('not-4:',[(q['sid'],q['head'],q['num'],len(q['opts'])) for q in out if len(q['opts'])!=4])
from itertools import groupby
for (sid,h),g in groupby(out,key=lambda x:(x['sid'],x['head'])):
    nums=[x['num'] for x in g]
    off=[(i,n) for i,n in enumerate(nums,1) if n!=i]
    if off and not sid.startswith('exam'): print('seq issue',sid,h,off[:3])
