import re, json
pages=open('micro.txt').read().split('\f')
qre=re.compile(r'^\s*(\d+)\s*[\.\-]\s*(.*)')
ore=re.compile(r'^\s*([a-eA-E])\s*[\.\)\-]\s*(.*)',0)
out=[]; cur=None; head=None
for pn in range(3,130):
    lines=pages[pn-1].split('\n')
    hdr=[l.strip() for l in lines if l.strip()][0]
    ctx=hdr.split('|',1)[1].strip()
    if pn<=56: sec=('chapter',ctx)
    elif pn<=88: sec=('exam',ctx)
    else: sec=('extra',None)
    key=(sec[0],sec[1])
    prevkey=(cur['kind'],cur['ctx']) if cur else None
    if cur is not None and prevkey!=key: cur=None; head=None
    for line in lines:
        s=line.strip()
        if not s or s==hdr or re.match(r'^\d+ \| P a g e',s) or s.startswith('Section ') or s.startswith('* The rate'): continue
        if s.startswith('➢'): head=s.lstrip('➢ ').strip(); cur=None; continue
        m=ore.match(line)
        if m and cur is not None and len(cur['opts'])<5 and m.group(1).lower()=='abcde'[len(cur['opts'])]:
            cur['opts'].append(m.group(2).strip()); cur['_last']='o'; continue
        m=qre.match(line)
        if m and (cur is None or len(cur['opts'])>=2):
            cur={'kind':sec[0],'ctx':sec[1],'head':head,'num':int(m.group(1)),'q':m.group(2).strip(),'opts':[],'page':pn,'_last':'q'}; out.append(cur); continue
        if cur is not None:
            if cur['_last']=='q': cur['q']+=' '+s
            else: cur['opts'][-1]+=' '+s
json.dump(out,open('micro_raw.json','w'),ensure_ascii=False)
from collections import OrderedDict
c=OrderedDict()
for q in out: c[(q['kind'],q['ctx'],q['head'])]=c.get((q['kind'],q['ctx'],q['head']),0)+1
for k,v in c.items(): print(k,v)
print('total',len(out),'opts dist',{n:sum(len(q['opts'])==n for q in out) for n in range(0,7)})
print('odd:',[(q['ctx'],q['head'],q['num'],len(q['opts'])) for q in out if len(q['opts']) not in (4,5)][:30])
