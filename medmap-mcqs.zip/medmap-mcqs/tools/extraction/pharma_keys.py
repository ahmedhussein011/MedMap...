import re,json
KEYS={}; NOTES={}
def put(name,s,n):
    d={}
    for num,l in re.findall(r'(\d+)\s+([a-ex])',s): d[int(num)]=l
    assert sorted(d)==list(range(1,n+1)),(name,sorted(set(range(1,n+1))-set(d)),len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
put('ch_endo',"""1 c,2 c,3 a,4 c,5 c,6 a,7 c,8 a,9 d,10 b,11 d,12 c,13 c,14 a,15 a,16 d,17 c,18 b,19 c,20 b,21 d,22 c,23 b,24 c,25 d,26 c,
27 b,28 c,29 a,30 c,31 b,32 d,33 b,34 a,35 c,36 b,37 b,38 d,39 a,40 a,41 c,42 d,43 b,44 b,45 c,46 d,47 d,48 c,49 a,50 d,51 b""",51)
put('ex_endo2324',"1 a,2 b,3 b,4 d,5 b,6 c,7 a,8 a,9 c,10 b,11 d,12 c,13 c,14 a,15 b,16 a,17 b,18 b",18)
put('ch_cns',"""1 a,2 c,3 a,4 b,5 c,6 d,7 a,8 c,9 b,10 d,11 c,12 d,13 c,14 d,15 c,16 d,17 b,18 c,19 c,20 c,21 c,22 c,23 d,24 c,25 b,26 d,
27 a,28 b,29 b,30 a,31 a,32 c,33 a,34 a,35 d,36 a,37 a,38 a,39 a,40 c,41 d,42 c,43 d,44 c,45 d,46 d,47 b,48 c,49 a,50 d,51 a""",51)
put('ex_cns2324',"1 d,2 c,3 c,4 c,5 a,6 d,7 c,8 d,9 c,10 d,11 c,12 c,13 b,14 d,15 a,16 b,17 a,18 c,19 a,20 c",20)
put('ch_chemo',"""1 a,2 c,3 d,4 b,5 c,6 b,7 c,8 c,9 d,10 b,11 a,12 c,13 a,14 c,15 d,16 c,17 c,18 c,
19 a,20 d,21 d,22 b,23 c,24 c,25 d,26 x,27 b,28 d,29 b,30 c,31 c,32 c,33 b,34 d,35 c,36 b,
37 c,38 a,39 c,40 a,41 a,42 d,43 c,44 d,45 d,46 b,47 d,48 b,49 d,50 d,51 a,52 d,53 c,54 a,
55 d,56 c,57 b,58 d,59 d,60 b,61 a,62 c,63 a,64 d,65 c,66 b,67 a,68 d,69 c,70 d,71 c,72 d""",72)
NOTES['ch_chemo']={26:"Source key lists two accepted answers for this question (c / a)."}
put('ex_chemo2324',"1 a,2 a,3 c,4 b,5 c,6 d,7 a,8 a,9 d,10 b,11 b,12 d,13 d,14 c,15 b,16 d,17 c,18 b,19 a,20 b,21 c,22 c",22)
put('ex_chemo_extra',"1 c,2 b,3 a,4 x,5 a,6 c,7 b,8 b,9 a,10 a,11 c,12 d,13 c,14 d,15 a,16 b,17 d,18 a,19 c,20 b,21 a,22 a",22)
NOTES['ex_chemo_extra']={4:"Source key lists two accepted answers for this question (c / d)."}
put('ex_endo',"""1 b,2 b,3 b,4 b,5 a,6 b,7 a,8 a,9 c,10 d,11 b,12 c,13 c,14 c,15 a,16 d,17 d,18 c,19 c,20 d,21 a,22 c,23 c,
24 b,25 a,26 c,27 a,28 d,29 c,30 b,31 a,32 b,33 a,34 b,35 d,36 a,37 a,38 d,39 c,40 c,41 d,42 b,43 c,44 b,45 a,46 b,
47 c,48 b,49 a,50 a,51 a,52 d,53 a,54 a,55 a,56 c,57 c,58 c,59 b,60 c,61 a,62 c,63 b,64 c,65 c,66 b,67 d,68 c,69 d,
70 a,71 a,72 a,73 d,74 b,75 b,76 b,77 b,78 b,79 c,80 d,81 a,82 b,83 c,84 c,85 c,86 a,87 c,88 d,89 x,90 b,91 a,92 a,
93 d,94 c,95 b,96 c,97 d,98 b,99 a,100 b,101 b,102 b,103 a,104 a,105 a,106 b,107 a,108 b,109 b,110 d,111 b,112 b,113 d,114 a""",114)
NOTES['ex_endo']={89:"Source key lists two accepted answers for this question (a / b)."}
put('ex_cns',"""1 d,2 c,3 b,4 c,5 b,6 b,7 d,8 c,9 b,10 c,11 a,12 c,13 c,14 a,15 d,16 b,17 b,18 d,19 a,20 b,21 c,22 b,23 c,24 c,25 c,26 a,27 d,
28 a,29 d,30 a,31 d,32 b,33 c,34 a,35 c,36 a,37 d,38 a,39 a,40 b,41 b,42 a,43 b,44 b,45 b,46 b,47 a,48 a,49 b,50 a,51 c,52 a,53 d,54 b,
55 d,56 d,57 b,58 c,59 a,60 c,61 c,62 d,63 c,64 d,65 a,66 a,67 c,68 d,69 a,70 a,71 b,72 b,73 a,74 c,75 d,76 c,77 d,78 d,79 a,80 b,81 c,
82 b,83 c,84 b,85 c,86 c,87 a,88 c,89 c,90 c,91 d,92 a,93 a,94 a,95 b,96 a,97 a,98 b,99 d,100 c,101 c,102 d,103 b,104 a,105 d,106 c,107 b,108 c,
109 d,110 b,111 d,112 b,113 c,114 d,115 d,116 d,117 b,118 c,119 a,120 b,121 b,122 a,123 d,124 a,125 d,126 c,127 b,128 b,129 a,130 c,131 b,132 c,133 d,134 b""",134)
if __name__=="__main__": json.dump({'KEYS':KEYS,'NOTES':NOTES},open('pharma_keys.json','w')); print({k:len(v) for k,v in KEYS.items()})
