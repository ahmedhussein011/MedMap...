import re,json
KEYS={}
def put(name,s,n):
    d={}
    for num,l in re.findall(r'(\d+)\s+([a-ex])',s): d[int(num)]=l
    assert sorted(d)==list(range(1,n+1)),(name,sorted(set(range(1,n+1))-set(d)),len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
put('ch_intro_git',"""1 c,2 a,3 c,4 a,5 c,6 b,7 a,8 d,9 b,10 b,11 b,12 b,13 c,14 d,15 b,16 d,17 c,18 b,19 c,20 d,21 b,22 a,23 b,24 b,25 d,26 a,27 b,
28 d,29 d,30 b,31 c,32 c,33 b,34 a,35 c,36 d,37 d,38 a,39 b,40 b,41 c,42 c,43 b,44 a,45 b,46 a,47 c,48 b,49 c,50 c,51 b,52 d,53 b,54 b,
55 d,56 c,57 b,58 a,59 c,60 a,61 c,62 a,63 a,64 d,65 b,66 c,67 a,68 b,69 d,70 a,71 a,72 b,73 b,74 d,75 c,76 b,77 b,78 a,79 d,80 d,81 d,
82 d,83 d,84 b,85 b,86 a,87 b,88 b,89 c,90 a,91 c,92 a,93 a,94 d,95 a,96 a,97 b,98 b,99 d,100 c,101 b,102 b,103 c,104 a,105 c,106 d,107 d,108 c,
109 d,110 a,111 c,112 c,113 d,114 a,115 b,116 c,117 b,118 b,119 c,120 c,121 a,122 d,123 b,124 b,125 b,126 a,127 d,128 d,129 c,130 d,131 b,132 a,133 c,134 b""",134)
put('ch_blood_tissue',"""1 b,2 c,3 c,4 d,5 c,6 a,7 c,8 c,9 c,10 c,11 c,12 c,13 c,14 d,15 b,16 d,17 b,18 b,19 c,20 d,21 d,22 a,
23 d,24 a,25 a,26 c,27 a,28 b,29 a,30 d,31 c,32 b,33 a,34 c,35 a,36 b,37 d,38 a,39 b,40 c,41 c,42 c,43 d,44 a,
45 b,46 c,47 b,48 c,49 a,50 d,51 b,52 c,53 a,54 d,55 c,56 c,57 d,58 c,59 c,60 c,61 a,62 c,63 b,64 b,65 b,66 a,
67 c,68 c,69 b,70 b,71 a,72 b,73 a,74 c,75 a,76 d,77 b,78 a,79 c,80 d,81 a,82 b,83 c,84 a,85 b,86 b,87 c,88 b,
89 c,90 a,91 c,92 c,93 d,94 d,95 a,96 b,97 d,98 b,99 d,100 b,101 d,102 d,103 c,104 a,105 b,106 d,107 b""",107)
put('ch_ento_immuno',"""1 a,2 b,3 d,4 d,5 a,6 b,7 a,8 b,9 b,10 c,11 a,12 b,13 c,14 d,15 a,16 d,17 b,
18 c,19 b,20 a,21 c,22 b,23 a,24 b,25 a,26 c,27 b,28 b,29 b,30 a,31 b,32 c,33 b,34 c,
35 c,36 x,37 b,38 c,39 c,40 b,41 b,42 a,43 d,44 b,45 c,46 a,47 c,48 b,49 c,50 b,51 c,
52 a,53 b,54 b,55 c,56 b,57 b,58 d,59 a,60 a,61 a,62 d,63 a,64 d,65 c,66 a""",66)
NOTES={'ch_ento_immuno':{36:"Source key lists two accepted answers for this question (a / b)."}}
put('exam2425_eom',"""1 c,2 b,3 b,4 c,5 a,6 d,7 b,8 a,9 c,10 b,11 b,12 a,13 b,14 c,
15 b,16 a,17 a,18 b,19 d,20 d,21 a,22 c,23 c,24 d,25 a,26 d,27 b,28 a,
29 a,30 b,31 a,32 c,33 b,34 c,35 b,36 b,37 a,38 b,39 d,40 d,41 b,42 c,
43 a,44 b,45 a,46 d,47 b,48 a,49 a,50 c,51 a,52 b,53 c,54 b,55 d,56 b""",56)
put('ex_intro_git',"""1 c,2 a,3 c,4 a,5 a,6 b,7 b,8 d,9 c,10 b,11 b,12 c,13 a,14 c,15 d,16 d,17 c,18 d,
19 d,20 b,21 b,22 d,23 b,24 b,25 a,26 b,27 c,28 b,29 a,30 b,31 b,32 c,33 a,34 a,35 c,36 d,
37 b,38 d,39 b,40 c,41 a,42 b,43 a,44 c,45 b,46 d,47 c,48 d,49 d,50 b,51 d,52 d,53 d,54 a,
55 d,56 c,57 b,58 d,59 b,60 b,61 c,62 d,63 a,64 b,65 c,66 a,67 b,68 d,69 b""",69)
put('ex_all',"""1 b,2 b,3 b,4 b,5 c,6 c,7 a,8 d,9 c,10 a,11 b,12 b,13 d,14 c,15 b,16 c,17 b,18 c,19 c,20 b,21 a,22 c,23 b,24 d,
25 c,26 b,27 a,28 c,29 b,30 a,31 d,32 c,33 d,34 d,35 b,36 c,37 a,38 c,39 c,40 b,41 b,42 a,43 a,44 c,45 d,46 d,47 b,48 c,
49 a,50 b,51 a,52 d,53 b,54 a,55 c,56 a,57 b,58 a,59 c,60 b,61 c,62 b,63 a,64 d,65 b,66 d,67 b,68 b,69 c,70 x,71 d,72 d,
73 a,74 b,75 b,76 b,77 c,78 b,79 c,80 b,81 b,82 c,83 b,84 a,85 c,86 d,87 b,88 b,89 b,90 a,91 b,92 b,93 b,94 c,95 c,96 d,
97 c,98 d,99 c,100 d,101 c,102 b,103 b,104 a,105 d,106 d,107 a,108 c,109 c,110 b,111 d,112 b,113 d,114 c,115 b,116 b,117 d,118 c,119 b,120 d""",120)
NOTES['ex_all']={70:"Source key lists two accepted answers for this question (b / d)."}
if __name__=="__main__": json.dump(KEYS,open('para_keys.json','w')); print({k:len(v) for k,v in KEYS.items()})
