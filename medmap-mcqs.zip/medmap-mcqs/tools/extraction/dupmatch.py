import json,re,difflib,sys
def norm(s): 
    s=re.sub(r'\d+\s*\|\s*page','',s.lower())
    return re.sub(r'[^a-z0-9 ]','',s).strip()
def sim(a,b): return difflib.SequenceMatcher(None,norm(a),norm(b)).ratio()
def run(path):
    D=json.load(open(path)); Q=D['questions']
    ver=[q for q in Q if q['answerStatus']=='source-verified']
    changed=[]; stats={'agree':0,'disagree':0,'adopted':0}
    for q in Q:
        if q['answerStatus'] not in ('independently-solved','needs-review','unsolved'): continue
        mine=q.get('correctOptionId') or q.get('tentativeOptionId')
        best=None
        for v in ver:
            if sim(q['question'],v['question'])<0.93: continue
            # every option of q must match an option of v
            mp={}
            ok=True
            for o in q['options']:
                cand=max(v['options'],key=lambda x:sim(o['text'],x['text']))
                if sim(o['text'],cand['text'])<0.85: ok=False;break
                mp[o['id']]=cand['id']
            if not ok or len(set(mp.values()))!=len(mp): continue
            if len(q['options'])!=len(v['options']): continue
            best=(v,mp); break
        if not best: continue
        v,mp=best
        inv={b:a for a,b in mp.items()}
        newans=inv.get(v['correctOptionId'])
        if newans is None: continue
        if mine:
            if mine==newans: stats['agree']+=1
            else: stats['disagree']+=1; changed.append((q['id'],mine,newans,v['id']))
        q['independentOptionId']=mine
        q['correctOptionId']=newans; q['answerStatus']='source-verified'
        q.pop('tentativeOptionId',None); q.pop('answerNote',None)
        q['answerNote']=f"Answer taken from an identical question that has a key in the same book ({v['id']})."
        q.pop('reviewNote',None) if q.get('reviewNote') and mine!=newans or True else None
        stats['adopted']+=1
    json.dump(D,open(path,'w'),ensure_ascii=False,indent=1)
    from collections import Counter
    print(path.split('/')[-1],stats,Counter(x['answerStatus'] for x in Q))
    for c in changed: print('   differs from my solution:',c)
for p in sys.argv[1:]: run(p)
