def k(s): return s.split()
KEYS = {
 "exam2025": k("a b d b d b a b d b c c b a c a c b a d c c b a c d c b c a  b d a b c a d a d c c b b b c a a b d c d d b b a d d d c b  c d c c a c b c a c b c c b a a c a b b b c b b d b c b d b  a a d c c a a c b b c a c d c c c b a d a d a b a c a c c b"),
 "exam2023": k("c d c c b a b a d c a a c d d b c a c b b d b a a d a c d b  d c b d b d c a a d a c c b a b c b b a c b c d c b b c b d  b d c b a b a d d b c d a c c d b c d c a b a c a a c d b d  c b a d b c b c c b d c b a a b d c d a b c a b c c a c a b"),
 "exam2022": k("c a b a a d b a b c b d b d b c a d c d a a c b d b b d b d  a a c X a X a d c a d a d b a b a a c d c d c d b a b c b d  a c c c a d c b a d a c a b d b d b c d c a b d a c d d a c  b a b c c a c a b d c b b a b d c b a b d c b c c d b b a d"),
 "extra_anat_basis": k("b c a b a d b a a d b c b d c b a d a d b c c d d a b b c c d a d a b d d c b c a b a d c a b c d c d"),
 "extra_anat_ul": k("d c a c b d d b d b d d b c b d c a d a b a a a b c b b c a b d c c a c a d c b b a c c d c d b c a b d b d c d c c c b b b b c c b b a a a a d a c d c d d c c d d d c b c c c d d b b d a c c c a b a d a c a c a d c b b a c c d b d a c d a b c b a c a b c d d c a c b d d d c b a c a c d b b a b c a a c b a d b b d b c a b c a a a a a b d b b c a a b d d d c a b b c c d d a c c c c a d b b c c d a b c c d d c c b b c a b d a d"),
 "extra_anat_emb": k("c d a b a c a d d c b c a a d c a c b a b d b c a a c c b a b d c b c a c d a c a c a b a b c a b b c b a b b a c b b a a b c d a b d a a a b c d a b c c a c b a a b c d a c a b d a c b"),
 "extra_hist_intro": k("c c a c c d b a a d"),
 "extra_hist_cyto": k("b d a c d c d b a c b d a d a d a a b c b c d d d c d d d b a c d a d a d a b a c b b a d a c d b d b d c a b c a"),
 "extra_hist_epi": k("d d c c a d d b a c b b c a c c c c b b a b b d d d c a c c d c d d b d d d a b d d d d b d a"),
 "extra_hist_ct": k("d d b c a d b a a c c d b c c a a d c a c c d a b a d a c c"),
 "extra_hist_blood": k("a b c b d a b b b c a d b b c b a c d c d b c d b a d a a c d"),
}
if __name__=="__main__":
    for n,v in KEYS.items(): print(n,len(v))
