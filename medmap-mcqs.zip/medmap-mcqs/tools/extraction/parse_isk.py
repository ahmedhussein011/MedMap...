import re, json
pages=open('isk.txt').read().split('\f')
SECTIONS=[("exam2025","End of Module EXAM 2025",3,18),("exam2023","End of Module EXAM 2023",19,34),("exam2022","End of Module EXAM 2022",35,50),
          ("extra_anat","Extra Anatomy",51,94),("extra_hist","Extra Histology",95,116)]
qre=re.compile(r'^\s*(\d+)\s*\.\s*(.*)')
ore=re.compile(r'^\s*([a-d])\s*[\.\)\-]\s*(.*)')
out=[]
for sid,label,a,b in SECTIONS:
    cur=None; head=None; qs=[]
    for pn in range(a,b+1):
        for line in pages[pn-1].split('\n'):
            s=line.strip()
            if not s or re.match(r'^ISK - 101 \|',s) or re.match(r'^\d+ \| P a g e',s): continue
            if s.startswith('➢'):
                head=s.lstrip('➢ ').strip(); cur=None; continue
            m=ore.match(line)
            if m and cur is not None and cur['opts'] is not None and len(cur['opts'])<4 and m.group(1)==('abcd'[len(cur['opts'])]):
                cur['opts'].append(m.group(2).strip()); cur['_last']='o'; continue
            m=qre.match(line)
            if m and (cur is None or len(cur['opts'])>=2):
                cur={'sid':sid,'head':head,'num':int(m.group(1)),'q':m.group(2).strip(),'opts':[],'page':pn,'_last':'q'}; qs.append(cur); continue
            if cur is not None:
                if cur['_last']=='q': cur['q']+=' '+s
                else: cur['opts'][-1]+=' '+s
    out+=qs
json.dump(out,open('isk_raw.json','w'),ensure_ascii=False)
from collections import Counter
c=Counter((q['sid'],q['head']) for q in out)
for k,v in c.items(): print(k,v)
bad=[(q['sid'],q['head'],q['num'],len(q['opts'])) for q in out if len(q['opts'])!=4]
print('not-4-options:',bad)
