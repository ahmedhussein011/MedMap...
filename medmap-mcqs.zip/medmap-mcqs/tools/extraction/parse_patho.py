import re, json
pages=open('patho.txt').read().split('\f')
qre=re.compile(r'^\s*(\d+)\s*[\.\-]\s*(.*)')
ore=re.compile(r'^\s*([a-eA-E])\s*[\.\)\-]\s*(.*)')
out=[]; cur=None; head=None; prevkey=None
for pn in range(3,81):
    lines=pages[pn-1].split('\n')
    L=[l.strip() for l in lines if l.strip()]
    if not L: continue
    hdr=L[0]; ctx=hdr.split('|',1)[1].strip() if '|' in hdr else ''
    kind='chapter' if pn<=54 else 'exam'
    key=(kind,ctx)
    if key!=prevkey: cur=None; head=None; prevkey=key
    for line in lines:
        s=line.strip()
        if not s or s==hdr or re.match(r'^\d+ \| P a g e',s) or s.startswith('Section ') or s.startswith('* The rate'): continue
        if s.startswith('➢'): head=s.lstrip('➢ ').strip(); cur=None; continue
        m=ore.match(line)
        if m and cur is not None and len(cur['opts'])<5 and m.group(1).lower()=='abcde'[len(cur['opts'])]:
            cur['opts'].append(m.group(2).strip()); cur['_last']='o'; continue
        m=qre.match(line)
        if m and (cur is None or len(cur['opts'])>=2):
            cur={'kind':kind,'ctx':ctx,'head':head,'num':int(m.group(1)),'q':m.group(2).strip(),'opts':[],'page':pn,'_last':'q'}; out.append(cur); continue
        if cur is not None:
            if cur['_last']=='q': cur['q']+=' '+s
            else: cur['opts'][-1]+=' '+s
json.dump(out,open('patho_raw.json','w'),ensure_ascii=False)
from collections import OrderedDict
c=OrderedDict()
for q in out: c[(q['kind'],q['ctx'],q['head'])]=c.get((q['kind'],q['ctx'],q['head']),0)+1
for k,v in c.items(): print(k,v)
print('total',len(out),{n:sum(len(q['opts'])==n for q in out) for n in range(0,7)})
print('odd:',[(q['ctx'],q['head'],q['num'],len(q['opts'])) for q in out if len(q['opts']) not in (4,5)][:30])
from itertools import groupby
for (k,cx,h),g in groupby(out,key=lambda x:(x['kind'],x['ctx'],x['head'])):
    nums=[x['num'] for x in g]
    if nums!=list(range(1,len(nums)+1)): print('seq',cx,h,[(i,n) for i,n in enumerate(nums,1) if n!=i][:3])
