import re,json
KEYS={}
def put(name,s,n):
    d={}
    for num,l in re.findall(r'(\d+)\s+([a-e])',s): d[int(num)]=l
    assert sorted(d)==list(range(1,n+1)),(name,sorted(set(range(1,n+1))-set(d)),len(d))
    KEYS[name]=[d[i] for i in range(1,n+1)]
put('ch_general',"1 b,2 c,3 d,4 d,5 a,6 d,7 c,8 a,9 a,10 c,11 d,12 b,13 c,14 c,15 d,16 d,17 b,18 c,19 d,20 c,21 b,22 c",22)
put('ch_immunity',"1 c,2 a,3 a,4 a,5 a,6 a,7 c,8 a,9 a,10 a,11 c,12 a,13 b,14 c,15 a,16 b,17 c,18 b,19 c,20 d,21 b,22 d,23 d,24 c",24)
put('ch_staph',"1 c,2 d,3 c,4 b,5 c,6 c,7 d,8 d,9 c,10 c,11 b,12 b,13 c,14 d,15 a",15)
put('ch_strep',"1 d,2 d,3 a,4 d,5 c,6 b,7 c,8 c,9 d,10 b,11 a,12 c,13 a,14 a,15 b,16 b,17 a,18 b,19 b,20 a,21 d,22 a,23 c,24 d,25 d",25)
put('ch_entero_neis',"1 d,2 d,3 c,4 d,5 a,6 c,7 a,8 b,9 d,10 d,11 b,12 d",12)
put('ch_coryne',"1 b,2 c,3 b,4 b,5 b,6 b,7 a,8 b",8)
put('ch_bacillus',"1 b,2 d,3 c,4 a,5 a,6 a,7 a,8 d,9 a,10 a",10)
put('ch_clostridium',"1 d,2 c,3 b,4 b,5 a,6 b,7 b,8 d,9 b",9)
put('ch_enterobact',"1 c,2 d,3 b,4 a,5 a,6 c,7 c,8 c,9 c,10 c,11 b,12 d,13 b,14 d,15 a,16 d",16)
put('ch_campy',"1 a,2 d,3 b,4 b,5 b,6 c,7 d,8 b,9 c,10 d,11 c,12 c",12)
put('ch_haemo',"1 d,2 b,3 a,4 d,5 c,6 c,7 c,8 b,9 b,10 c,11 a",11)
put('ch_myco',"1 a,2 a,3 b,4 d,5 d,6 d,7 c,8 c,9 c,10 c,11 c,12 b,13 d,14 c,15 c",15)
put('ch_spiro',"1 b,2 d,3 d,4 c,5 b,6 d,7 d,8 d,9 b",9)
put('ch_mycoplasma',"1 a,2 b,3 b,4 b,5 a,6 d,7 a,8 c,9 a,10 a,11 c,12 b,13 c,14 a,15 a,16 a,17 c,18 c",18)
put('ch_rickettsia',"1 a,2 b,3 d,4 a,5 a,6 b,7 b,8 c,9 b,10 b,11 d,12 d,13 a",13)
put('ch_hepatitis',"1 c,2 c,3 d,4 b,5 d,6 b,7 c,8 d,9 d,10 b",10)
put('ch_retro_ortho',"1 b,2 b,3 b,4 c,5 a,6 a,7 d,8 c,9 b",9)
put('ch_paramyxo',"1 b,2 b,3 b,4 b,5 d,6 b,7 d,8 c,9 b,10 b",10)
put('ch_toga',"1 d,2 c,3 c,4 a,5 a,6 c,7 c,8 c",8)
put('ch_arbo',"1 b,2 d,3 d,4 a,5 b,6 a,7 a,8 b,9 b,10 b,11 c,12 c",12)
put('ch_filo',"1 c,2 d,3 a,4 c,5 c,6 b,7 d,8 d",8)
put('ch_herpes',"1 b,2 a,3 a,4 d,5 d,6 d,7 a,8 d,9 c,10 a,11 a,12 c,13 a,14 d,15 d,16 b,17 d,18 b,19 a,20 b,21 c,22 b",22)
put('ch_pox',"1 c,2 c,3 a,4 b,5 b,6 a,7 a",7)
put('ch_hpv',"1 c,2 c,3 d,4 d,5 b,6 c,7 c,8 d,9 c,10 b,11 b,12 c,13 d",13)
put('ch_mycology',"1 b,2 b,3 d,4 c,5 a,6 d,7 b,8 b,9 a,10 d,11 c,12 a,13 b,14 a,15 d,16 c,17 b,18 a,19 b,20 c,21 a,22 a",22)
put('ch_applied',"1 a,2 c,3 d,4 a,5 a,6 a,7 b,8 b,9 c,10 c,11 c,12 a,13 c,14 b,15 a,16 c,17 a,18 b,19 c",19)
put('exam2425_eom',"""1 d,2 d,3 b,4 c,5 a,6 b,7 b,8 b,9 d,10 a,11 d,12 b,13 d,14 c,15 a,16 b,
17 b,18 a,19 c,20 a,21 b,22 d,23 d,24 d,25 c,26 d,27 d,28 c,29 b,30 d,31 b,32 c,
33 a,34 d,35 d,36 c,37 b,38 b,39 b,40 d,41 a,42 a,43 a,44 a,45 b,46 a,47 c,48 c,
49 c,50 b,51 c,52 a,53 c,54 c,55 c,56 b,57 c,58 c,59 b,60 d,61 d,62 d,63 b,64 b""",64)
put('ex_general',"1 b,2 e,3 c,4 d,5 b,6 a,7 a,8 a,9 c,10 b,11 e,12 d,13 c,14 c,15 c,16 d,17 d,18 a,19 b,20 b,21 c,22 b,23 e,24 b,25 c,26 a,27 d,28 c,29 e,30 d,31 e,32 c,33 c,34 b,35 a,36 b,37 a,38 c,39 d,40 e,41 c,42 b,43 d,44 b,45 e",45)
put('ex_immunity',"""1 d,2 c,3 a,4 e,5 c,6 c,7 d,8 d,9 b,10 b,11 b,12 c,13 d,14 c,15 c,
16 d,17 d,18 e,19 c,20 d,21 d,22 e,23 d,24 c,25 c,26 e,27 d,28 e,29 b,30 c,
31 e,32 d,33 a,34 b,35 d,36 c,37 e,38 a,39 c,40 c,41 b,42 e,43 b,44 e,45 c,
46 a,47 c,48 c,49 c,50 e,51 a,52 a,53 e,54 c,55 b,56 a,57 c,58 b,59 e,60 b,
61 a,62 d,63 a,64 b,65 b,66 c,67 d,68 d,69 b,70 a,71 c,72 d,73 d,74 a,75 d""",75)
put('ex_bact',"""1 c,2 c,3 b,4 c,5 e,6 d,7 a,8 d,9 a,10 e,11 d,12 c,13 b,14 d,15 d,16 b,17 c,18 b,19 d,20 d,21 d,22 d,
23 d,24 c,25 d,26 e,27 b,28 e,29 b,30 d,31 b,32 d,33 c,34 c,35 d,36 d,37 e,38 c,39 b,40 c,41 e,42 b,43 d,44 b,
45 b,46 d,47 e,48 a,49 d,50 c,51 a,52 d,53 c,54 c,55 c,56 c,57 c,58 d,59 d,60 c,61 d,62 e,63 e,64 e,65 e,66 c,
67 e,68 e,69 b,70 d,71 c,72 b,73 d,74 e,75 c,76 c,77 b,78 d,79 c,80 b,81 d,82 c,83 b,84 a,85 c,86 b,87 c,88 e""",88)
put('ex_viro',"""1 a,2 e,3 b,4 e,5 c,6 a,7 b,8 c,9 a,10 d,11 c,12 d,13 e,14 d,15 e,16 a,17 a,
18 e,19 d,20 d,21 b,22 b,23 b,24 d,25 b,26 d,27 a,28 c,29 e,30 e,31 a,32 b,33 e,34 e,
35 e,36 a,37 a,38 c,39 b,40 a,41 c,42 d,43 d,44 a,45 d,46 e,47 d,48 a,49 e,50 c,51 d,
52 b,53 a,54 b,55 d,56 b,57 d,58 b,59 d,60 c,61 d,62 b,63 c,64 b,65 b,66 d,67 d,68 b""",68)
if __name__=="__main__": json.dump(KEYS,open('micro_keys.json','w')); print({k:len(v) for k,v in KEYS.items()})
