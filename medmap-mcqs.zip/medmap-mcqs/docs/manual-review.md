# MedMap MCQs – manual review list

Generated from the question files. Total questions: **5,277**.

| Answer status | Questions |
|---|---:|
| source-verified | 4,817 |
| independently-solved | 408 |
| needs-review | 52 |

* **source-verified** – the answer was read from the book’s own answer key (including key images), or taken from an identical keyed question elsewhere in the same book.
* **independently-solved** – the book has no key for that question; the answer was worked out with medical knowledge. These are listed in `independently-solved.csv` for instructors to check. They are never presented as coming from the book.
* **needs-review** – the answer is ambiguous, cancelled, listed twice, or contradicted elsewhere in the book. These questions are shown to students but are **not scored**.

## Status by subject

| Subject | Source-verified | Independently solved | Needs review |
|---|---:|---:|---:|
| Module 101 – Anatomy | 567 | 0 | 1 |
| Module 101 – Histology | 303 | 0 | 2 |
| Module 102 – Biochemistry | 588 | 0 | 22 |
| Module 102 – Physiology | 312 | 0 | 1 |
| Module 205 – Anatomy | 222 | 0 | 0 |
| Module 205 – Histology | 136 | 0 | 0 |
| Module 205 – Physiology | 307 | 0 | 0 |
| Module 309 – Microbiology | 698 | 174 | 5 |
| Module 309 – Parasitology | 638 | 79 | 11 |
| Module 310 – Pathology | 532 | 53 | 2 |
| Module 310 – Pharmacology | 514 | 102 | 8 |

## 1. Questions that need review (not scored)

| Question ID | Book page | Reason | Tentative answer (not scored) |
|---|---:|---|---|
| M101-ANAT-EX2023-Q057 | 26 | The book's key for this question says B (Paraxial mesoderm), but paraxial mesoderm is part of the intraembryonic mesoderm. The identical question in Exam 2022 (M101-ANAT-EX2022-Q060) has key D. Tentative: D. | D. Descending anastomotic branch. |
| M101-HIST-EX2022-Q034 | 39 | Marked 'Cancelled' in the source answer key. | — |
| M101-HIST-EX2022-Q036 | 39 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q045 | 8 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q068 | 11 | Source answer key entry is not a valid option letter (printed as 'v'); answer could not be matched. | — |
| M102-BIOC-EX2025-Q070 | 11 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q072 | 11 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q085 | 13 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q087 | 13 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2025-Q092 | 14 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2024-Q049 | 25 | The book's key says B (Deoxy-sugar). Reduction of monosaccharides gives sugar alcohols, and the identical question in the Extra Carbohydrates set (M102-BIOC-CARB-Q029) has key D. Tentative: D. | D. Sugar alcohol |
| M102-BIOC-EX2024-Q086 | 29 | The book's key says B (Transferrin), which is not a hemoprotein. The identical question in the Extra Hemoproteins set (M102-BIOC-HEMO-Q008) has key C (Cytochromes). Tentative: C. | C. Cytochromes |
| M102-BIOC-EX2022-Q070 | 43 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q073 | 44 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q074 | 44 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q080 | 44 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q086 | 45 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q087 | 45 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q090 | 46 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q097 | 47 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q104 | 47 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q105 | 48 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q107 | 48 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q109 | 48 | Marked 'Cancelled' in the source answer key. | — |
| M102-BIOC-EX2022-Q111 | 48 | Marked 'Cancelled' in the source answer key. | — |
| M102-PHYS-EX2022-Q018 | 37 | Marked 'Cancelled' in the source answer key. | — |
| M309-MICRO-TOGA-Q008 | 41 | The book's key says C (hematogenous route), which conflicts with standard teaching that rabies virus reaches the CNS by retrograde axonal transport along peripheral nerves (option A). Tentative: A. | A. Along the afferent peripheral neurons |
| M309-MICRO-EX2324EOM-Q006 | 57 | Option 'a' contains a likely typo ('flow content of calcium and dipicolinic acid'); option 'b' (cortex/coat impermeability) is also arguable. Tentative: a (high calcium dipicolinate). | A. Their flow content of calcium and dipicolinic acid |
| M309-MICRO-EX2324EOM-Q033 | 60 | Both 'b' (Th2 IL-4 driving IgE switching) and 'd' (mast-cell histamine) are involved in atopy; the question does not specify which. Tentative: b. | B. Production of large amounts of IL-4 by Th-2 cells. |
| M309-MICRO-EX2324EOM-Q056 | 63 | Superantigen status of exfoliatin vs. M protein is textbook-dependent; the question is ambiguous. Tentative: c (M protein). | C. Streptococcal M protein |
| M309-MICRO-EX2526-Q042 | 86 | Which method is 'preferred' for Mycoplasma diagnosis is source- and textbook-dependent (culture vs serology/PCR). Tentative: b. | B. Antibody detection. |
| M309-PARA-ENT-Q036 | 36 | Source key lists two accepted answers for this question (a / b). | — |
| M309-PARA-EX2324EOM-Q051 | 45 | Kato-Katz is used for both S. mansoni (b) and Trichuris (c); the question allows two correct options. Tentative: b. | B. Schistosoma mansoni. |
| M309-PARA-EX2324EOM-Q055 | 46 | Which listed infection lacks eosinophilia is not clear-cut from standard texts. Tentative: d. | D. Strongyloides stercoralis. |
| M309-PARA-EX2324FIN-Q012 | 48 | None of the listed tests is clearly a delayed-hypersensitivity test in standard teaching (Bachman and Casoni are immediate-type; Montenegro, not listed, is delayed). Tentative: d. | D. Cruzin test. |
| M309-PARA-EX2425FIN-Q029 | 62 | Which parasite causes two different types of anaemia is textbook-dependent (hookworm vs. D. latum vs. schistosomiasis). Tentative: c. | C. Ancylostoma duodenale. |
| M309-PARA-EX2526-Q003 | 63 | Both Echinococcus granulosus (a) and Toxocara canis (c) are acquired from dogs; the question allows more than one answer. Tentative: c. | C. Toxocara canis. |
| M309-PARA-EX2526-Q041 | 68 | The phrase 'in high blood samples' is unclear (probably night blood). Sheathed, kinky microfilariae suggest Brugia malayi. Tentative: c. | C. Brugia malayi. |
| M309-PARA-EX2526-Q043 | 68 | Kato-Katz is used for both S. mansoni (b) and Trichuris (c); the question allows two correct options. Tentative: b. | B. Schistosoma mansoni. |
| M309-PARA-EX2526-Q046 | 68 | Which listed infection lacks eosinophilia is not clear-cut from standard texts. Tentative: d. | D. Strongyloides stercoralis. |
| M309-PARA-EX2526-Q059 | 70 | Taenia eggs cannot be differentiated morphologically; the intended answer depends on the course text. Tentative: b. | B. Taenia solium and Taenia saginata. |
| M309-PARA-XALL-Q070 | 87 | Source key lists two accepted answers for this question (b / d). | — |
| M310-PATH-REN-Q007 | 19 | Source key lists two accepted answers for this question (a & d). | — |
| M310-PATH-REN-Q012 | 20 | Source key lists two accepted answers for this question (a & b). | — |
| M310-PHARM-XENDO-Q089 | 23 | Source key lists two accepted answers for this question (a / b). | — |
| M310-PHARM-CHEMO-Q026 | 58 | Source key lists two accepted answers for this question (c / a). | — |
| M310-PHARM-XCHEMO-Q004 | 68 | Source key lists two accepted answers for this question (c / d). | — |
| M310-PHARM-EX2425-Q003 | 71 | Both semaglutide (d) and metformin (b) rarely cause hypoglycaemia on their own; the question allows more than one reading. Tentative: d. | D. Semaglutide |
| M310-PHARM-EX2425-Q020 | 74 | Every listed urate-lowering class can precipitate gout flares at initiation, so no option is clearly correct. No tentative answer given. | — |
| M310-PHARM-EX2526-Q012 | 81 | Both 'b' (decreases estrogen production) and 'e' (used in breast cancer) are true of letrozole; the question allows more than one answer. Tentative: e. | E. It is used in the treatment of breast cancer. |
| M310-PHARM-EX2526-Q020 | 83 | Buspirone's recognised side effects (dizziness, nausea, headache, palpitations) do not clearly match any single option. Tentative: e. | E. Tachycardia |
| M310-PHARM-EX2526-Q045 | 87 | 'Advantage of aminoglycoside therapy' does not clearly match any single option. No tentative answer given. | — |

## 2. Scored questions with a reviewer note

These keep their answer but carry a note: a printing defect that was reconstructed, or a solved answer that needs a second look.

| Question ID | Book page | Note |
|---|---:|---|
| M101-ANAT-BASIS-Q045 | 56 | Source formatting defect: option list had a stray 'i.' label and only a/b/c. Reconstructed to 4 options; the source key (c) matches the lung-to-left-atrium option. Please confirm against the printed book. |
| M102-PHYS-EX2024-Q033 | 23 | Options are printed as a table image in the book (the PDF text layer holds stale options from Q32). Options transcribed from the image; please confirm against the printed page. |
| M309-MICRO-EX2526-Q036 | 85 | Answered by elimination (the other three options are incorrect for the standard tube agglutination test); please confirm wording. |
| M310-PATH-EX2324-Q059 | 61 | Source typesetting defect: options a and b were printed on one line and the option letters were then shifted. Reconstructed to four options; the source key (d) matches the 'pale nuclei with nuclear grooving' option. |
| M310-PHARM-XENDO-Q107 | 25 | Source typesetting defect: two options were printed on one line. Split into four options; the source key matches the reconstructed option list. |
| M310-PHARM-XENDO-Q113 | 26 | Source typesetting defect: two options were printed on one line. Split into four options; the source key matches the reconstructed option list. |

## 3. Other things to know

* Figure-matching exercises (“Match column A with column B”, 11 in the NEU-205 book) are **not MCQs** and are not in the question bank. Their pages are saved in `assets/extra-content/` for the planned “Figure Matching” section.
* No explanations exist in the books, so the explanation field is empty for every question.
* Answers that were read from key images were transcribed by reading the images; spot-checks against medical knowledge found no mismatches, but a second human read of the keys is recommended.
